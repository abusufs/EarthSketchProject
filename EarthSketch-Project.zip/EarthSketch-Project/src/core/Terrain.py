''' 
This class is for grouping multiple properties (width, height, grid spacing,
latitude and elevation values) as well as soil properties of a terrain together.

''' 
from dataclasses import dataclass
import numpy as np
from typing import List, Tuple, Optional
from .SoilValidator import SoilValidator 
from .Exceptions import TerrainValidationError

@dataclass
class Terrain:
    
    def __init__(self, width: int, height: int, spacing: float, latitude: float, elevations: List[List[float]]): # Terrain object properties
        
        if width <= 0 or height <= 0: # cant have negative or zero dimensions
            raise ValueError(f"Width ({width}) and height ({height}) must be positive")
        
        if spacing <= 0: # spacing needs to be greater than 0
            raise ValueError(f"Grid spacing ({spacing}) must be positive")
        
        if isinstance(elevations, np.ndarray):
            # Fast path: whole-grid validation in C, no Python loop over 1M cells.
            if elevations.ndim != 2 or elevations.shape != (height, width):
                raise ValueError(f"Expected elevation grid of shape ({height}, {width}), got {elevations.shape}")
            if not np.issubdtype(elevations.dtype, np.number):
                raise TypeError(f'Elevation value must be numeric, got {elevations.dtype}')
            if not np.isfinite(elevations).all():
                raise ValueError("Elevation grid contains NaN or infinite values")
        else:
            if len(elevations) != height: # check rows match height
                raise ValueError(f"Expected {height} rows in elevations, got {len(elevations)}")

            for row_idex, row in enumerate(elevations): # validate the elevation grid
                if len(row) != width: # each row should have width number of columns
                    raise ValueError(f"Row {row_idex}: Expected {width} columns, got {len(row)}")

                for val in row: # check for invalid elevation vals
                    if not isinstance(val, (int, float)): # make sure all values are numbers
                        raise TypeError(f'Elevation value must be numeric, got {type(val)}')
                    
        self.width = width  # width in grid cells
        self.height = height  # height in grid cells
        self.latitude = latitude  # location in degrees
        self.spacing = spacing   # spacing between adjacent terrain points (meters)
        self.elevations = elevations  # elevations of points within grid (2D list)
        
        #  [row][col] -- accessing sand at row 5, col 
        #  soil needs defaults 
        #  "for _ in range(width)" meaning we don't care about the loop variable
        
        self._initialize_soil_from_terrain() # * gradient/elevation-aware defaults, not flat constants
        self.is_soil_modified = False 

        """Slope magnitude (rise/run) at each cell via central differences."""
         
    def _compute_slope(self) -> np.ndarray:
        elev = np.asarray(self.elevations, dtype=np.float64)
        dzdy, dzdx = np.gradient(elev, self.spacing)
        return np.sqrt(dzdx**2 + dzdy**2)
        

    def _initialize_soil_from_terrain(self) -> None:
        """
        Gradient/elevation-aware default soil init (replaces flat constants).
        - Sand can't hold on slopes steeper than ~35 deg (angle of repose for
          dry sand) -> sand fraction decays with slope, silt/clay compensate.
        - Depth is erosion-limited on steep ground, and thicker in local
          topographic lows where material accumulates.
        """
        slope = self._compute_slope()
        slope_deg = np.degrees(np.arctan(slope))
        
        ref_angle = max(np.percentile(slope_deg, 90), 1e-3)  # this terrain's own "steep" threshold
        steepness = np.clip(slope_deg / ref_angle, 0.0, 1.0)

        base_sand, base_silt, base_clay = 50.0, 30.0, 20.0
        sand = base_sand * (1.0 - 0.8 * steepness)
        freed = base_sand - sand
        silt = base_silt + freed * 0.55
        clay = base_clay + freed * 0.45
        total = sand + silt + clay
        sand, silt, clay = sand / total * 100.0, silt / total * 100.0, clay / total * 100.0

        elev = np.array(self.elevations, dtype=np.float64)
        padded = np.pad(elev, 1, mode='edge')
        local_mean = (padded[0:-2,0:-2]+padded[0:-2,1:-1]+padded[0:-2,2:]+
                      padded[1:-1,0:-2]+padded[1:-1,1:-1]+padded[1:-1,2:]+
                      padded[2:,  0:-2]+padded[2:,  1:-1]+padded[2:,  2:]) / 9.0
        lowness = np.clip(local_mean - elev, 0, None)
        lowness_norm = lowness / (lowness.max() + 1e-6)

        depth = 1.0 * np.exp(-2.0 * steepness) * (0.6 + 0.8 * lowness_norm)
        depth = np.clip(depth, 0.05, None)  # thin skin everywhere, never literally bare

        self.sand = sand
        self.silt = silt
        self.clay = clay
        self.depth = depth
        
    def print_summary(self):
        
        print("Width: " + str(self.width))
        print('Height: ' + str(self.height))
        print("Grid spacing: " + str(self.spacing))
        print("Latitude: " + str(self.latitude))     
        
    
    # GETTERS
    
    def getElevation(self, row: int, col: int) -> float: # returns elevation at specific row and col
        self._validate_coordinates(row, col) # validate first
        return self.elevations[row][col]
        
    def setElevation(self, row, col, val): # set elevation at specified row and col
        
        self.elevations[row][col] = val
        
    def getDimensions(self) -> Tuple[int,int]: 
        
        return self.width, self.height
    
    def getSpacing(self) -> float: # return spacing between points in terrain
        
        return self.spacing
    
    def getLatitude(self) -> float: # return latitude of terrain
        
        return self.latitude
    
    def getElevations(self) -> List[List[float]]: # return full elevation grid
        return self.elevations
        
    def get_soil_texture(self, row: int, col: int) -> Tuple[float, float, float]:
        self._validate_coordinates(row, col) # validate coords
        return (self.sand[row][col], self.silt[row][col], self.clay[row][col]) # return sand, silt, clay percentages
    
    def get_soil_depth(self, row: int, col: int) -> float: # get soil depth at grid point   
        self._validate_coordinates(row, col) 
        return self.depth[row][col]
    
    def get_all_soil_data(self, row: int, col: int) -> Tuple[float, float, float, float]: # get all soil properties at grid point
        self._validate_coordinates(row, col)
        return (self.sand[row][col], self.silt[row][col], 
                self.clay[row][col], self.depth[row][col]) # return all soil props at once
    
    # SETTERS
    
    def set_elevation(self, row: int, col: int, value: float) -> None: 
        self._validate_coordinates(row, col) # validate coordinates
        
        if not isinstance(value, (int, float)): # make sure value is numeric
            raise TypeError(f"Elevation must be numeric, got {type(value)}") # error message
        
        self.elevations[row][col] = value # update elevation
    
    def set_soil_texture(self, row: int, col: int, sand: float, silt: float, clay: float) -> None: # set soil percentages must sum to 100%
        self._validate_coordinates(row, col) # validate coordinates
        
        # validation of percentages, physical law says sand+silt+clay = 100
        # if they dont sum to 100, data is invalid
        
        SoilValidator.validate_soil_percentages(sand, clay, silt)
        
        # clamp percentages to valid range
        sand = max(0.0, min(100.0, sand))
        silt = max(0.0, min(100.0, silt))
        clay = max(0.0, min(100.0, clay))
        
        # normalize to ensure they sum to 100
        total = sand + silt + clay
        if total > 0:
            self.sand[row][col] = (sand / total) * 100.0
            self.silt[row][col] = (silt / total) * 100.0
            self.clay[row][col] = (clay / total) * 100.0
        else:
            self.sand[row][col] = 33.33
            self.silt[row][col] = 33.33
            self.clay[row][col] = 33.34
            
        self.is_soil_modified = True # mark soil was changed
    
    def set_soil_depth(self, row: int, col: int, depth: float) -> None: # set siol depth in meters
        self._validate_coordinates(row, col)
        
        SoilValidator.validate_soil_depth(depth) # depth cant be negative because soil cant go above ground
        
        self.depth[row][col] = depth # update depth
        
        self.is_soil_modified = True
    
    def set_all_soil_data(self, row: int, col: int, sand: float, silt: float, 
                          clay: float, depth: float) -> None: # set all soil properties at once
        self.set_soil_texture(row, col, sand, silt, clay)
        self.set_soil_depth(row, col, depth)
    
    # Bulk Operations - better performance for painting many cells
    # instead of updating one cell at a time, we update whole grids which is 100X faster
    
    def get_elevation_grid_numpy(self) -> np.ndarray:  # returns elevations as nump array for faster processing
        return np.array(self.elevations, dtype=np.float32)
    
    def get_soil_grids_numpy(self) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]: # returns all four grids as numpy arrays
        """Return all soil grids as NumPy arrays."""
        return (np.array(self.sand, dtype=np.float32),
                np.array(self.silt, dtype=np.float32),
                np.array(self.clay, dtype=np.float32),
                np.array(self.depth, dtype=np.float32))
    
    def get_soil_classification(self, row: int, col: int) -> str: # classify soil type using USDA triangle
        sand, silt, clay = self.get_soil_texture(row, col) # get percentages
        
        # Simplified USDA classification
         
        if sand > 80:
            return "Sand" # 80%+ sand = drains quickly + low nutrients
        
        elif sand > 50 and clay < 20:
            return "Sandy Loam" # most sand with some silt/clay   
        
        elif silt > 50:
            return "Silt Loam" # high silt content (silky texture)
        elif clay > 40:
            return "Clay" # heavy &sticky, holds water too well
        
        elif clay > 30:
            return "Clay Loam" # significant clay but some sand/silt
        
        elif clay > 20:
            return "Loam" # balanced sand/silt/clay
        
        elif sand > 30:
            return "Sandy Loam" # more sand than silt or clay
        
        elif silt > 30:
            return "Silt Loam" # more silt than sand or clay
        
        else:
            return "Loam" # alanced soil
    
    # Validation - prevents out-of-bounds errors
    
    def _validate_coordinates(self, row: int, col: int) -> None: # check row and col are within grid bounds
        
        if not (0 <= row < self.height):
            raise IndexError(f"Row {row} out of bounds (0-{self.height-1})")
            # check row is between 0 and height-1
            # IndexError is standard Python error for bad indices
        
        if not (0 <= col < self.width):
            raise IndexError(f"Column {col} out of bounds (0-{self.width-1})")
            # same for column
    
    def validate_soil_data(self) -> bool:
        sand = np.asarray(self.sand, dtype=np.float64)
        silt = np.asarray(self.silt, dtype=np.float64)
        clay = np.asarray(self.clay, dtype=np.float64)
        depth = np.asarray(self.depth, dtype=np.float64)

        in_range = lambda a: bool(a.min() >= 0) and bool(a.max() <= 100)
        if not (in_range(sand) and in_range(silt) and in_range(clay)):
            return False

        total = sand + silt + clay
        if not bool(np.abs(total - 100.0).max() <= 0.01):
            return False

        if not bool(depth.min() >= 0):
            return False

        return True
        
    def get_elevation_stats(self) -> dict: # return statistics about elevation data
        
        flat = [val for row in self.elevations for val in row]
        # flatten 2D list to 1D list
        # for each row in elevations, then each val in row
        
        return {
            'min': min(flat),
            # lowest elevation
            'max': max(flat),
            # highest elevation
            'mean': sum(flat) / len(flat),
            # average elevation
            'count': len(flat)
            # total number of points (width * height)
        }
    
    def get_soil_stats(self) -> dict: # return statistics about soil data
        # flatten all grids
        sand_flat = [val for row in self.sand for val in row]
        silt_flat = [val for row in self.silt for val in row]
        clay_flat = [val for row in self.clay for val in row]
        depth_flat = [val for row in self.depth for val in row]
        
        return {
            'sand': {
                'min': min(sand_flat), 
                'max': max(sand_flat), 
                'mean': sum(sand_flat) / len(sand_flat)
            },
            'silt': {
                'min': min(silt_flat), 
                'max': max(silt_flat), 
                'mean': sum(silt_flat) / len(silt_flat)
            },
            'clay': {
                'min': min(clay_flat), 
                'max': max(clay_flat), 
                'mean': sum(clay_flat) / len(clay_flat)
            },
            'depth': {
                'min': min(depth_flat), 
                'max': max(depth_flat), 
                'mean': sum(depth_flat) / len(depth_flat)
            }
        }  # returns nested dictionary with stats for each property
    
    # OUTPUT
    # human read summary of terrain
    # Can be used for debugging and user feedback
    
    def print_summary(self) -> None: # print terrain summary
        # quick way to see whats in the terrain
        # useful for debugging and user feedback 
        # Do Later on 
        
        print("Terrain Summary:")
        print("  Dimensions: " + str(self.width) + " x " + str(self.height) + " grid")
        print("  Cell size: " + str(self.spacing) + " m")
        print("  Real size: " + str(self.width * self.spacing) + " x " + str(self.height * self.spacing) + " m")
        # calculate actual ground coverage in meters
        
        print("  Latitude: " + str(self.latitude) + "°")
        
        elev_stats = self.get_elevation_stats()
        print("  Elevation: min=" + str(round(elev_stats['min'], 1)) + "m, max=" + str(round(elev_stats['max'], 1)) + "m, mean=" + str(round(elev_stats['mean'], 1)) + "m")
        # round off to 1 decimal place
        
        soil_stats = self.get_soil_stats()
        print("  Soil: sand=" + str(round(soil_stats['sand']['mean'], 1)) + "%, silt=" + str(round(soil_stats['silt']['mean'], 1)) + "%, clay=" + str(round(soil_stats['clay']['mean'], 1)) + "%, depth=" + str(round(soil_stats['depth']['mean'], 2)) + "m")
        # show average soil properties
        
        print("  Soil modified: " + str(self.is_soil_modified))
        # show if user has made changes
    
    def to_elv_format(self) -> List: # convert soil data to .elv file format string
        # .elv format can store multiple bands of data
        # this function formats the data as a string
        
        lines = []
        
        # Header
        lines.append(str(self.width) + " " + str(self.height) + " " + str(self.spacing) + " " + str(self.latitude)+"\n")
        # first line: dimensions and location
        
        # Write soil data in row-major order
        #convert each matrix in a string line
        elv= self.toString(self.elevations)
        sand= self.toString(self.sand)
        clay= self.toString(self.clay)
        silt= self.toString(self.silt)
        depth= self.toString(self.depth)

        # combine all strings into one list
        lines.append(elv)
        lines.append(sand)
        lines.append(clay)
        lines.append(silt)
        lines.append(depth)

        return lines #return the list
    
    def apply_weighed_depth_update(self,array,r_min,r_max,c_min,c_max, weights, update_fn):
        """
        Apply update_fn to the cells of `array` that fall inside `mask`,
        clipped to the terrain's bounds. update_fn receives the current
        values (a 1D array) and must return the new values (same shape).
        """
        r0,r1 = max(0,r_min) , min(r_max, self.height)
        c0,c1 = max(0,c_min) , min(c_max, self.width)

        if r0>r1 or c0>c1:
            return

        sub_weights = weights[r0-r_min:r1 - r_min, c0 -c_min:c1-c_min]
        region = array[r0:r1, c0:c1]
        region[:] = update_fn(region, sub_weights)

        self.is_soil_modified = True

    def apply_weighted_update(self, array, r_min, r_max, c_min, c_max, weights, target):
        """
        Blend `target` into `array` within the clamped region using per-cell
        weights in [0.0, 1.0]. `weights` must be shaped for the *unclamped*
        (r_min, r_max, c_min, c_max) box; `target` is a scalar or broadcastable array.
        """
        r0, r1 = max(0, r_min), min(r_max, self.height)
        c0, c1 = max(0, c_min), min(c_max, self.width)
        if r0 >= r1 or c0 >= c1:
            return

        sub_weights = weights[r0 - r_min:r1 - r_min, c0 - c_min:c1 - c_min]
        region = array[r0:r1, c0:c1]
        region[:] = region * (1.0 - sub_weights) + target * sub_weights

        self.is_soil_modified = True

#Method for converting a matrix of data from terrain object into a single string
    def toString(self,matrix: List[List[float]])-> str:
        height= len(matrix)#row length
        width = len(matrix[0])#column length
        string=""

        for row in range(height):
            row_values = []#each row is stored here
            # one row of output
                    
            for col in range(width):
                row_values.append(f"{matrix[row][col]:.3f}") 
                # add each value with 3 decimal places
            string= string+ " ".join(row_values)+" "
                    # combine all columns into one string
        return string
