"""
 Shared exception classes for the terrain core module.

All terrain-related errors inherit from TerrainError, so calling code
can catch broadly (except TerrainError) or narrowly (except TerrainLoadError)
depending on how specific it needs to be.
"""

class TerrainError(Exception):
    """Base class for all terrain-related errors."""
    pass

class TerrainLoadError(TerrainError):
    """Raised when a .elv file can't be read or parsed into a Terrain."""
    pass

class TerrainSaveError(TerrainError):
    """Raised when a Terrain can't be written to a .elv file."""
    pass

class TerrainValidationError(TerrainError):
    """Raised when terrain data violates a validation rule."""
    pass