"""
TerrainLoader module for loading .elv files into Terrain objects.
Also supports validation, error handling, and security checks.

Assumes the elv file is in this format:

width height spacing latitude - header

elevation elevation elevation... - elevation data
elevation elevation elevation...

"""



import os # for file operations and path checking
import re # for whitespace handling and pattern matching
from typing import List, Union # for type hints
from pathlib import Path # object-oriented path handling (cleaner than os.path)
import numpy as np

from .Terrain import Terrain 

class TerrainLoadError(Exception): # custom exception for terrain loading errors
    pass
    

class TerrainLoader:
    """
    Handles loading Terrain objects from .elv files.
    Uses static methods for file operations so we dont need to instantiate.
    """
    
    @staticmethod # allow calling TerrainLoader.load("file.elv") directly
    def load(file_path: Union[str, Path]) -> Terrain:

        file_path = Path(file_path) # convert to Path object if string

        # SECURITY & VALIDATION CHECKS

        if not file_path.exists():
            raise TerrainLoadError("File not found: " + str(file_path))

        if not file_path.is_file():
            raise TerrainLoadError("Path is a directory, not a file: " + str(file_path))

        file_size = file_path.stat().st_size
        if file_size == 0: # no data available
            raise TerrainLoadError("File is empty: " + str(file_path))

        if file_path.suffix.lower() != '.elv':
            print("Warning: File extension is '" + file_path.suffix + "', expected '.elv'")

        # READ & PARSING

        try:
            with open(file_path, 'r', encoding='utf-8') as file:

                header_line = file.readline().strip()
                if not header_line:
                    raise TerrainLoadError("File is empty or missing header")

                header_parts = header_line.split()
                if len(header_parts) != 4:
                    raise TerrainLoadError(
                        "Invalid header. Expected 'width height spacing latitude', "
                        "got " + str(len(header_parts)) + " values"
                    )

                try:
                    width = int(header_parts[0])
                    height = int(header_parts[1])
                    spacing = float(header_parts[2])
                    latitude = float(header_parts[3])
                except ValueError as e:
                    raise TerrainLoadError("Header contains invalid numeric values: " + str(e))

                if width <= 0 or height <= 0:
                    raise TerrainLoadError("Width (" + str(width) + ") and height (" + str(height) + ") must be positive")
                if spacing <= 0:
                    raise TerrainLoadError("Grid spacing (" + str(spacing) + ") must be positive")
                if not (-90 <= latitude <= 90):
                    raise TerrainLoadError("Latitude " + str(latitude) + " must be between -90 and 90")

                # Read everything after the header in one go so we can decide
                # whether this is a band-structured file (new TerrainSaver
                # format: "BAND: <name>" sections) or a legacy plain
                # elevation-only file (old format, e.g. the sample .elv files
                # in data/). Both must keep working.
                remaining_lines = file.readlines()

        except OSError as e:
            raise TerrainLoadError("Error reading file: " + str(e))
        except UnicodeDecodeError as e:
            raise TerrainLoadError("File encoding error (try saving as UTF-8): " + str(e))

        has_bands = any(line.strip().upper().startswith("BAND:") for line in remaining_lines)

        if has_bands:
            bands = TerrainLoader._parse_bands(remaining_lines, width, height)

            if "elevation" not in bands:
                raise TerrainLoadError("File has BAND sections but is missing a required 'BAND: elevation' section")

            terrain = Terrain(width, height, spacing, latitude, bands["elevation"])

            # Soil bands are optional — if present, they override the
            # gradient-aware defaults Terrain.__init__ already set up.
            if "sand" in bands and "silt" in bands and "clay" in bands:
                terrain.sand = bands["sand"]
                terrain.silt = bands["silt"]
                terrain.clay = bands["clay"]
            elif any(b in bands for b in ("sand", "silt", "clay")):
                raise TerrainLoadError("File must include all three of BAND: sand / silt / clay, or none of them")

            if "depth" in bands:
                terrain.depth = bands["depth"]

            if not terrain.validate_soil_data():
                raise TerrainLoadError("Loaded soil data failed validation (percentages/depth out of range)")

            return terrain

        # Legacy plain elevation-only format — unchanged behaviour.
        elevations = TerrainLoader._parse_grid(remaining_lines, width, height, start_line_number=1)
        return Terrain(width, height, spacing, latitude, elevations)

    @staticmethod
    def _parse_grid(lines, width: int, height: int, start_line_number: int) -> list:
        """Parse `height` rows of `width` whitespace-separated floats out of `lines`."""
        expected_count = width * height
        text = "".join(lines)
        tokens = text.split()

        if len(tokens) == expected_count:
            try:
                flat = np.array(tokens, dtype=np.float64)
                return flat.reshape(height, width)
            except ValueError:
                pass  # fall through to the slow path so we can report which value is bad

        # Slow path: only hit for malformed files, so speed doesn't matter here.
        return TerrainLoader._parse_grid_slow(lines, width, height, start_line_number)

    @staticmethod
    def _parse_grid_slow(lines, width: int, height: int, start_line_number: int) -> list:
        """Original line-by-line parser — kept only for precise error messages on bad files."""
        all_values = []
        line_number = start_line_number

        for line in lines:
            line_number += 1
            line = line.strip()
            if not line:
                continue
            for part in re.split(r'\s+', line):
                if part:
                    try:
                        all_values.append(float(part))
                    except ValueError:
                        raise TerrainLoadError(
                            "Line " + str(line_number) + ": Invalid number '" + part + "'"
                        )

        expected_count = width * height
        actual_count = len(all_values)
        if actual_count != expected_count:
            raise TerrainLoadError(
                "Expected " + str(expected_count) + " values, got " + str(actual_count) + ". "
                "Check that the section contains " + str(height) + " rows of " + str(width) + " values."
            )

        grid = []
        idx = 0
        for _ in range(height):
            row_values = []
            for _ in range(width):
                row_values.append(all_values[idx])
                idx += 1
            grid.append(row_values)
        return grid

    @staticmethod
    def _parse_bands(lines, width: int, height: int) -> dict:
        """Split a band-structured file into {band_name: grid} using 'BAND: <name>' markers."""
        KNOWN_BANDS = {"elevation", "sand", "silt", "clay", "depth"}
        bands = {}
        current_name = None
        current_lines = []

        def flush():
            if current_name is not None:
                if current_name in bands:
                    raise TerrainLoadError(f"Duplicate BAND section: '{current_name}'")
                bands[current_name] = TerrainLoader._parse_grid(current_lines, width, height, start_line_number=0)

        for raw_line in lines:
            stripped = raw_line.strip()
            if stripped.upper().startswith("BAND:"):
                flush()
                current_name = stripped.split(":", 1)[1].strip().lower()
                if current_name not in KNOWN_BANDS:
                    raise TerrainLoadError(f"Unknown BAND type: '{current_name}'")
                current_lines = []
            else:
                current_lines.append(raw_line)
        flush()

        if current_name is None:
            raise TerrainLoadError("File contains no valid BAND sections")

        return bands