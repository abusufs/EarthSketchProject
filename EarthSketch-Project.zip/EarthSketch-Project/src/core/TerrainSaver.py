from pathlib import Path
from typing import Union
from .Terrain import Terrain

class TerrainSaveError(Exception):
    pass

class TerrainSaver:
    @staticmethod
    def save_all(terrain: Terrain, file_path: Union[str, Path]) -> None:
        """Save elevation + all soil data (sand, silt, clay, depth) to a .elv file."""
        file_path = Path(file_path)
        file_path.parent.mkdir(parents=True, exist_ok=True)

        # Validate before saving 
        if not terrain.validate_soil_data():
            raise TerrainSaveError("Terrain soil data is invalid – cannot save.")

        lines = []
        # Header: width height spacing latitude
        lines.append(f"{terrain.width} {terrain.height} {terrain.spacing} {terrain.latitude}")

        # Write each band as a separate block, each with its own header line.
        # We'll use a simple convention: a line with "BAND: <name>" before each grid.
        # You can adapt this to whatever format you prefer.
        bands = [
            ("elevation", terrain.elevations),
            ("sand", terrain.sand),
            ("silt", terrain.silt),
            ("clay", terrain.clay),
            ("depth", terrain.depth),
        ]
        for name, grid in bands:
            lines.append(name)
            
            values = lines.append(" ".join(f"{v:.3f}" for row in grid for v in row))
            lines.append(values)

        all_data = "\n".join(lines)

        try: 
            with open(file_path, "w") as f:
                f.write(all_data)
        except OSError as e:
            raise TerrainSaveError(f"Error writing file: {e}")

        # Verify
        if not file_path.exists() or file_path.stat().st_size == 0:
            raise TerrainSaveError(f"Save verification failed: {file_path} is missing or empty")

    # You can also add separate save functions if needed, but they would need a corresponding loader.