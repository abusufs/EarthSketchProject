"""
This class is a collection of validation methods for any soil data being loaded/saved/editted.
"""

from .Exceptions import TerrainValidationError
import numpy as np

class SoilValidator:

    VALID_SOIL_TYPES =  {"sand", "clay", "silt"}
    
    @staticmethod
    def validate_soil_percentages(sand: float, silt: float, clay: float) -> None:

        # Checks if all soil values are from 0 to 100
        for name, val in [("sand", sand), ("silt", silt), ("clay", clay)]:
            if not isinstance(val, (int, float,np.floating)):
                raise TerrainValidationError(
                    f"{name.capitalize()} must be numeric, got {type(val).__name__}"
                )

            if not 0 <= val <= 100:
                raise TerrainValidationError(
                    f"{name.capitalize()} must be a value from 0 to 100, got {val}"
                )

        # Checks if soil percentages sum to 100
        total = sand + silt + clay

        if abs(total - 100.0) > 0.01:
            raise TerrainValidationError(
                f"Soil percentages must sum to 100, got {total}"
            )

    @staticmethod
    def validate_soil_depth(depth: float) -> None:

        if not isinstance(depth, (int, float)):
            raise TerrainValidationError(
                f"Soil depth must be numeric, got {type(depth).__name__}"
            )

        if depth < 0:
            raise TerrainValidationError(
                f"Soil depth cannot be negative, got {depth}"
            )

    @staticmethod
    def validate_soil_data(sand: float, silt: float, clay: float, depth: float) -> None:

        SoilValidator.validate_soil_percentages(sand, silt, clay)

        SoilValidator.validate_soil_depth(depth)
