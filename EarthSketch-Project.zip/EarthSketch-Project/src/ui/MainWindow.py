"""
MainWindow.py - Main application window integrating all EarthSketch components.
"""

import os
from PySide6.QtWidgets import (
    QApplication,
    QMainWindow,
    QWidget,
    QPushButton,
    QLabel,
    QVBoxLayout,
    QHBoxLayout,
    QFormLayout,
    QGroupBox,
    QLineEdit,
    QSlider,
    QDoubleSpinBox,
    QComboBox,
    QFileDialog,
    QCheckBox,
    QMessageBox,
    QScrollArea,
)
from PySide6.QtCore import Qt, QEvent
from PySide6.QtGui import QMouseEvent, QWheelEvent, QShortcut, QKeySequence
from ..painting.UndoManager import UndoManager
from .UserGuide import UserGuideDialog


# Import our project classes
from ..core.Terrain import Terrain
from ..core.TerrainLoader import TerrainLoader, TerrainLoadError
from ..core.TerrainSaver import TerrainSaver, TerrainSaveError
from ..rendering.Renderer import Renderer
from ..rendering.Camera import Camera
from ..painting.RayCast import RayCast
from ..painting.BrushManager import BrushManager

class MainWindow(QMainWindow):

    def __init__(self):
        super().__init__()

        self.setWindowTitle("Earth Sketch 3D")
        self.resize(1600, 1024)
        self.is_stroking = False

        # --- Initialise components to None ---
        self.terrain: Terrain = None
        self.renderer: Renderer = None
        self.camera: Camera = None
        self.raycast: RayCast = None
        self.brush_manager: BrushManager = None
        self.undo_manager: UndoManager = None  

        # --- Mouse state for camera controls ---
        self.is_orbiting = False
        self.is_panning = False
        self.last_mouse_x = 0
        self.last_mouse_y = 0           

        self.setup_ui()
        self.setup_connections()
        self.setup_mouse_events()

    # UI Setup

    def setup_ui(self):
        # Main widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout()
        central_widget.setLayout(main_layout)

        #  Left Sidebar 
        sidebar = QVBoxLayout()

        # Title
        title = QLabel("Earth Sketch 3D")
        title.setStyleSheet("font-size: 24px; font-weight: bold;")
        sidebar.addWidget(title)

        subtitle = QLabel("Terrain Editor")
        sidebar.addWidget(subtitle)

        #  Paint Mode Group 
        # Split out of what used to be one big "Painting" box: that box had
        # grown to ~10 rows of controls stacked in a single QVBoxLayout, so
        # whenever the window was short, Qt squeezed it down below what its
        # own labels needed and the text overlapped into unreadable smudges.
        # Three smaller, focused group boxes each stay short enough to keep
        # their natural (readable) size, and the sidebar scroll area below
        # takes care of anything that still doesn't fit vertically.
        mode_group = QGroupBox("Paint Mode")
        mode_layout = QVBoxLayout()

        mode_label = QLabel("Paint Mode")
        self.paintModeCombo = QComboBox()
        self.paintModeCombo.addItems(["Soil", "Depth"])
        mode_layout.addWidget(mode_label)
        mode_layout.addWidget(self.paintModeCombo)

        depth_mode_label = QLabel("Depth Edit")
        self.depthModeCombo = QComboBox()
        self.depthModeCombo.addItems(["Add", "Subtract", "Set"])
        mode_layout.addWidget(depth_mode_label)
        mode_layout.addWidget(self.depthModeCombo)

        mode_group.setLayout(mode_layout)
        sidebar.addWidget(mode_group)

        #  Soil Composition Group 
        # A QFormLayout gives each field its own row (label left, spinbox
        # right) instead of cramming three label+spinbox pairs side by side
        # in one QHBoxLayout, which is what was forcing everything to shrink
        # below a readable width in the old layout.
        composition_group = QGroupBox("Soil Composition")
        composition_layout = QFormLayout()
        composition_layout.setLabelAlignment(Qt.AlignLeft)

        self.sandSpin = QDoubleSpinBox(); self.sandSpin.setRange(0, 100); self.sandSpin.setValue(50.0)
        self.siltSpin = QDoubleSpinBox(); self.siltSpin.setRange(0, 100); self.siltSpin.setValue(30.0)
        self.claySpin = QDoubleSpinBox(); self.claySpin.setRange(0, 100); self.claySpin.setValue(20.0)
        composition_layout.addRow("Sand %", self.sandSpin)
        composition_layout.addRow("Silt %", self.siltSpin)
        composition_layout.addRow("Clay %", self.claySpin)

        self.soilSumLabel = QLabel("Sum: 100.0%")
        composition_layout.addRow(self.soilSumLabel)

        composition_group.setLayout(composition_layout)
        sidebar.addWidget(composition_group)

        #  Brush Group 
        brush_group = QGroupBox("Brush")
        brush_layout = QVBoxLayout()

        # Brush size slider
        brush_size_label = QLabel("Brush Size")
        self.brushSize = QSlider(Qt.Horizontal)
        self.brushSize.setMinimum(1)
        self.brushSize.setMaximum(100)
        self.brushSize.setValue(25)

        self.brushSizeValue = QLabel("25")
        self.brushSize.valueChanged.connect(self._on_brush_size_changed)

        brush_layout.addWidget(brush_size_label)
        brush_layout.addWidget(self.brushSize)
        brush_layout.addWidget(self.brushSizeValue)

        # Brush depth slider
        depth_label = QLabel("Depth")
        self.brushDepth = QSlider(Qt.Horizontal)
        self.brushDepth.setMinimum(1)
        self.brushDepth.setMaximum(100)
        self.brushDepth.setValue(1)

        self.brushDepthValue = QLabel("1")

        brush_layout.addWidget(depth_label)
        brush_layout.addWidget(self.brushDepth)
        brush_layout.addWidget(self.brushDepthValue)

        brush_group.setLayout(brush_layout)
        sidebar.addWidget(brush_group)

        #  Terrain Controls 
        terrain_group = QGroupBox("Terrain")
        terrain_layout = QVBoxLayout()

        self.btnGenerate = QPushButton("Generate New Terrain")
        self.btnReset = QPushButton("Reset Terrain")

        terrain_layout.addWidget(self.btnGenerate)
        terrain_layout.addWidget(self.btnReset)

        terrain_group.setLayout(terrain_layout)
        sidebar.addWidget(terrain_group)
        
        #  Soil Depth View
        depth_group = QGroupBox("Soil Depth View")
        depth_layout = QVBoxLayout()

        self.chkDepth = QCheckBox("Show bed of nails")
        self.chkDepth.setChecked(True)
        self.chkDepth.setToolTip(
            "Show soil depth as coloured pins hanging from the surface.\n"
            "The terrain turns see-through so the pins inside are visible."
        )
        depth_layout.addWidget(self.chkDepth)

        exag_label = QLabel("Depth exaggeration")
        self.depthExag = QSlider(Qt.Horizontal)
        self.depthExag.setMinimum(5)
        self.depthExag.setMaximum(60)
        self.depthExag.setValue(15)
        self.depthExag.setToolTip(
            "Soil depth is under a metre on terrain hundreds of metres tall.\n"
            "This scales the pins so depth differences are visible."
        )
        self.depthExagValue = QLabel("15% of terrain height")

        depth_layout.addWidget(exag_label)
        depth_layout.addWidget(self.depthExag)
        depth_layout.addWidget(self.depthExagValue)

        depth_group.setLayout(depth_layout)
        sidebar.addWidget(depth_group)

        # Undo/Redo group
        history_group = QGroupBox("History")
        history_layout = QHBoxLayout()
        self.btnUndo = QPushButton("Undo")
        self.btnRedo = QPushButton("Redo")
        history_layout.addWidget(self.btnUndo)
        history_layout.addWidget(self.btnRedo)
        history_group.setLayout(history_layout)
        sidebar.addWidget(history_group)

        #  Save / Load 
        file_group = QGroupBox("Save / Load")
        file_layout = QVBoxLayout()

        self.btnSave = QPushButton("Save Terrain")
        self.btnLoad = QPushButton("Load Terrain")

        file_layout.addWidget(self.btnSave)
        file_layout.addWidget(self.btnLoad)

        file_group.setLayout(file_layout)
        sidebar.addWidget(file_group)

        #  Help
        help_group = QGroupBox("Help")
        help_layout = QVBoxLayout()

        self.btnGuide = QPushButton("User Guide")
        self.btnGuide.setToolTip("Open the interactive user guide (F1)")
        help_layout.addWidget(self.btnGuide)

        help_group.setLayout(help_layout)
        sidebar.addWidget(help_group)

        self._guide_dialog = None

        # Push everything up
        sidebar.addStretch()

        # Sidebar widget
        sidebar_widget = QWidget()
        sidebar_widget.setLayout(sidebar)

        # Wrap the sidebar in a scroll area instead of giving it a fixed
        # width/height on its own. Previously, if the panel's natural
        # (readable) height didn't fit in the window, Qt would squeeze every
        # row down to fit rather than showing a scrollbar - that's what made
        # the Painting section unreadable. Now, if content doesn't fit, the
        # user scrolls the panel instead of the text getting crushed.
        sidebar_scroll = QScrollArea()
        sidebar_scroll.setWidget(sidebar_widget)
        sidebar_scroll.setWidgetResizable(True)
        sidebar_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        sidebar_scroll.setFixedWidth(300)

        #  PyVista Viewport 
        self.renderer = Renderer(self)
        
        #  Main Layout 
        main_layout.addWidget(sidebar_scroll)
        main_layout.addWidget(self.renderer.interactor, 1)

        # Keep the window from being resized so short that even the
        # restructured panel would need to fight for space.
        self.setMinimumSize(1000, 650)

        #  Status Bar 
        self.statusBar().showMessage("Ready - Load or generate a terrain")

    # Connections

    def setup_connections(self):
        self.btnGenerate.clicked.connect(self.generate_terrain)
        self.btnReset.clicked.connect(self.reset_terrain)
        self.btnSave.clicked.connect(self.save_terrain)
        self.btnLoad.clicked.connect(self.load_terrain)
        self.btnUndo.clicked.connect(self.undo)
        self.btnRedo.clicked.connect(self.redo)
        self.btnGuide.clicked.connect(self.open_user_guide)
        QShortcut(QKeySequence("F1"), self, self.open_user_guide)

        self.sandSpin.valueChanged.connect(self._apply_custom_soil)
        self.siltSpin.valueChanged.connect(self._apply_custom_soil)
        self.claySpin.valueChanged.connect(self._apply_custom_soil)
        self.paintModeCombo.currentTextChanged.connect(self.change_paint_mode)
        self.depthModeCombo.currentTextChanged.connect(self.change_depth_mode)
        self.brushDepth.valueChanged.connect(self._on_brush_depth_changed)

        # These two were never wired up: the checkbox and slider existed and
        # looked interactive, but nothing called toggle_depth_view() or
        # change_depth_exaggeration() when they changed - clicking "Show bed
        # of nails" did nothing, and the terrain rendered see-through on
        # every load/generate regardless of the checkbox because the
        # renderer's default (show_depth=True) was never being overridden.
        self.chkDepth.toggled.connect(self.toggle_depth_view)
        self.depthExag.valueChanged.connect(self.change_depth_exaggeration)
        # Sync the slider's enabled state to the checkbox's actual state now
        # that toggling it does something.
        self.depthExag.setEnabled(self.chkDepth.isChecked())

    # Mouse Events (for Camera controls)

    def setup_mouse_events(self):
        """Connect mouse events to the plotter interactor."""
        # PyVista's interactor gives us mouse events via Qt
        self.renderer.interactor.installEventFilter(self)

    def open_user_guide(self):
        """Open the interactive user guide (non-modal, so it can stay open
        beside the app while the user follows along)."""
        if self._guide_dialog is None:
            self._guide_dialog = UserGuideDialog(self)
        self._guide_dialog.show()
        self._guide_dialog.raise_()
        self._guide_dialog.activateWindow()
    
    def toggle_depth_view(self, checked: bool):
        """Switch between the solid soil-type view and the see-through depth view."""
        self.renderer.set_depth_visible(checked)
        self.depthExag.setEnabled(checked)
        self.statusBar().showMessage(
            "Depth view on - terrain is see-through so the soil-depth pins are visible"
            if checked else
            "Depth view off - showing the solid soil-type surface"
        )

    def change_depth_exaggeration(self, value: int):
        """Rescale the depth pins. True depths are unchanged - only the drawing is scaled."""
        self.depthExagValue.setText(f"{value}% of terrain height")
        self.renderer.set_depth_exaggeration(value / 100.0)

    def eventFilter(self, obj, event):
        """Handle mouse events on the plotter."""
        if obj == self.renderer.interactor:
            event_type = event.type()
            # Use QEvent.Type constants (or the int constants)
            if event_type == QEvent.Type.MouseButtonPress:
                self.mouse_press_event(event)
                return True 
            elif event_type == QEvent.Type.MouseMove:
                if self.is_stroking or self.is_orbiting:
                    self.mouse_move_event(event)
                    return True
            elif event_type == QEvent.Type.MouseButtonRelease:
                self.mouse_release_event(event)
                return True 
            elif event_type == QEvent.Type.Wheel:
                self.wheel_event(event)
                return True
        return super().eventFilter(obj, event)

    def mouse_move_event(self, event):
        """Handle painting and camera rotation."""

        # Left-click painting
        if self.is_stroking:
            self._paint_at(event)
            return

        # Right-click camera rotation
        if self.is_orbiting and self.camera is not None:
            if not (event.buttons() & Qt.RightButton):
                self.is_orbiting=False
                return



        dx = event.position().x() - self.last_mouse_x
        dy = event.position().y() - self.last_mouse_y

        self.camera.orbit(dx * 0.3, dy * 0.3)

        self.last_mouse_x = event.position().x()
        self.last_mouse_y = event.position().y()

    def mouse_press_event(self, event: QMouseEvent):
        """Left-click paints, right-click rotates the camera."""

        if event.button() == Qt.LeftButton:
            if self.brush_manager is not None and self.raycast is not None:
                self.is_stroking = True
                self.brush_manager.begin_stroke()
                self._paint_at(event)

        elif event.button() == Qt.RightButton:
            self.is_orbiting = True
            self.last_mouse_x = event.position().x()
            self.last_mouse_y = event.position().y()

    def mouse_release_event(self, event):
        """Stop painting or camera rotation."""

        if event.button() == Qt.LeftButton:
            if self.is_stroking:
                self.is_stroking = False

                if self.brush_manager is not None:
                    self.brush_manager.end_stroke()

        elif event.button() == Qt.RightButton:
            self.is_orbiting = False

    def wheel_event(self, event):
        """Handle scroll wheel: zoom."""
        if self.camera is not None:
            # QWheelEvent returns angleDelta in eighths of a degree
            delta = event.angleDelta().y() / 120  # Normalize to scroll steps
            self.camera.zoom(delta * 0.5)  # Zoom speed

    # Core Functions

    def generate_terrain(self):
        """
        Generate a simple terrain programmatically for testing.
        This creates a 50x50 grid with a simple hill.
        """
        self.statusBar().showMessage("Generating terrain...")

        try:
            # Create a falt 100x100 grid
            width = 100
            height = 100
            spacing = 1.0
            latitude = 0.0

            # Build a simple hill in the center
            import math
            elevations = []
            for row in range(height):
                row_values = []
                for col in range(width):
                    # Distance from center
                    dx = (col - width / 2) / (width / 2)
                    dy = (row - height / 2) / (height / 2)
                    # Simple Gaussian hill
                    elev = 5.0 * math.exp(-(dx*dx + dy*dy) * 2.0)
                    row_values.append(elev)
                elevations.append(row_values)

            # Create the Terrain object
            self.terrain = Terrain(width, height, spacing, latitude, elevations)

            # Set up renderer and camera
            self._setup_visuals()

            self.statusBar().showMessage(f"Terrain generated: {width}x{height}")

        except Exception as e:
            QMessageBox.critical(self, "Error", f"Failed to generate terrain: {e}")
            self.statusBar().showMessage("Error generating terrain")

    def reset_terrain(self):
        """Reset the terrain (remove from view)."""
        
        # Remove the actor from the plotter
        self.renderer.clear_terrain()
        self.terrain = None
        self.raycast = None           
        self.brush_manager = None
        self.undo_manager = None
        self.statusBar().showMessage("Terrain Reset")

        
    def load_terrain(self):
        """Load a terrain from a .elv file."""
        file_path, _ = QFileDialog.getOpenFileName(
            self,
            "Load Terrain",
            "",
            "ELV Files (*.elv);;All Files (*)"
        )

        if not file_path:
            return

        self.statusBar().showMessage(f"Loading terrain from {os.path.basename(file_path)}...")

        try:
            # Use TerrainLoader to load the file
            self.terrain = TerrainLoader.load(file_path)

            # Set up renderer and camera
            self._setup_visuals()

            self.statusBar().showMessage(f"Loaded: {os.path.basename(file_path)}")

        except TerrainLoadError as e:
            QMessageBox.critical(self, "Load Error", str(e))
            self.statusBar().showMessage("Load failed")
        except Exception as e:
            QMessageBox.critical(self, "Unexpected Error", str(e))
            self.statusBar().showMessage("Load failed")

    def save_terrain(self):
        """Save the current terrain to a .elv file."""
        if self.terrain is None:
            QMessageBox.warning(self, "No Terrain", "No terrain loaded to save.")
            return

        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "Save Terrain",
            "",
            "ELV Files (*.elv);;All Files (*)"
        )

        if not file_path:
            return

        self.statusBar().showMessage(f"Saving terrain to {os.path.basename(file_path)}...")

        try:
            # Use TerrainSaver to save the file
            TerrainSaver.save_all(self.terrain, file_path)
            self.statusBar().showMessage(f"Saved: {os.path.basename(file_path)}")

        except TerrainSaveError as e:
            QMessageBox.critical(self, "Save Error", str(e))
            self.statusBar().showMessage("Save failed")
        except Exception as e:
            QMessageBox.critical(self, "Unexpected Error", str(e))
            self.statusBar().showMessage("Save failed")

    def _paint_at(self, event):
        x = int(event.position().x())
        y = int(event.position().y())
        hit = self.raycast.pick_at_screen(x, y)
        if hit is not None:
            self.brush_manager.paint(hit)

    def _apply_custom_soil(self):
        sand, silt, clay = self.sandSpin.value(), self.siltSpin.value(), self.claySpin.value()
        total = sand + silt + clay
        self.soilSumLabel.setText(f"Sum: {total:.1f}%")

        if abs(total - 100.0) > 0.01:
            self.soilSumLabel.setStyleSheet("color: red;")
            return
        self.soilSumLabel.setStyleSheet("")

        if self.brush_manager is not None:
            norm_sand = sand / total
            norm_silt = silt / total
            norm_clay = clay / total
            self.brush_manager.set_custom_soil(norm_sand * 100, norm_silt * 100, norm_clay * 100)

    def change_paint_mode(self, mode: str):
        self.statusBar().showMessage(f"Paint mode: {mode}")
        is_soil = mode.lower() == "soil"
        for spin in (self.sandSpin, self.siltSpin, self.claySpin):
            spin.setEnabled(is_soil)
        self.depthModeCombo.setEnabled(not is_soil)
        self.brushDepth.setEnabled(not is_soil)
        if self.brush_manager is not None:
            self.brush_manager.set_paint_mode(mode.lower())
        if self.renderer is not None:
            self.renderer.set_colour_mode(mode.lower()) 

    def change_depth_mode(self, mode: str):
        if self.brush_manager is not None:
            self.brush_manager.set_depth_mode(mode.lower())

    def _on_brush_depth_changed(self, value: int):
        self.brushDepthValue.setText(str(value))
        if self.brush_manager is  None:
            return
        if self.depthModeCombo.currentText().lower() =="set":
            self.brush_manager.set_depth_value(float(value))
        else:
            self.brush_manager.set_depth_delta(float(value))

    # Internal Setup Methods

    def _setup_visuals(self):
        """
        Set up the renderer and camera for the current terrain.
        This is called after loading or generating a terrain.
        """
        if self.terrain is None:
            return

        # Set the terrain in the renderer
        self.renderer.set_terrain(self.terrain)

        # Create the camera if it doesn't exist
        if self.camera is None:
            self.camera = Camera(self.renderer.plot)

        # Focus the camera on the terrain
        self.camera.focus_on_terrain(self.terrain)

        self.raycast = RayCast(
            plotter =self.renderer.plot, 
            #terrain_mesh =self.renderer.mesh,
            cell_spacing = self.terrain.spacing,
            terrain=self.terrain
        )

        self.undo_manager = UndoManager(
            terrain=self.terrain,
            renderer=self.renderer
        )

        self.brush_manager = BrushManager(
            terrain = self.terrain,
            renderer=self.renderer,
            undo_manager=self.undo_manager
        )

        self.brush_manager.set_size(self.brushSize.value())
        self._apply_custom_soil()
        self.change_paint_mode(self.paintModeCombo.currentText())
        self.brush_manager.set_depth_mode(self.depthModeCombo.currentText().lower())
        self.brush_manager.set_depth_value(float(self.brushDepth.value()))
        
        # Update status
        self.statusBar().showMessage(   
            f"Terrain: {self.terrain.width}x{self.terrain.height}, "
            f"modified: {self.terrain.is_soil_modified}"
        )
    

    def _on_brush_size_changed(self, value: int):
        self.brushSizeValue.setText(str(value))
        if self.brush_manager is not None:
            self.brush_manager.set_size(value)

    # Keyboard Shortcuts

    def keyPressEvent(self, event):
        """Handle keyboard shortcuts."""
        # Undo and Redo keysequence: Undo = Ctrl + Z/Ctrl+Y and Redo = Shift + Ctrl + Z
        if event.matches(QKeySequence.Undo):
            self.undo()
        elif event.matches(QKeySequence.Redo):
            self.redo()

        # Reset camera
        elif event.key() == Qt.Key_R:
            if self.camera is not None:
                self.camera.reset()
                self.statusBar().showMessage("Camera reset")

        elif event.key() == Qt.Key_1:
            self.paintModeCombo.setCurrentText("Soil")
        elif event.key() == Qt.Key_2:
            self.paintModeCombo.setCurrentText("Depth")
                # Decrease brush size
        elif event.key() == Qt.Key_BracketLeft:
            new_size = max(1, self.brushSize.value() - 5)
            self.brushSize.setValue(new_size)

        # Increase brush size
        elif event.key() == Qt.Key_BracketRight:
            new_size = min(100, self.brushSize.value() + 5)
            self.brushSize.setValue(new_size)

        else:
            super().keyPressEvent(event)


    def undo(self):
        if self.undo_manager is None:
            return
        if self.undo_manager.undo():
            self.statusBar().showMessage("Undo")
        else:
            self.statusBar().showMessage("Nothing to undo.")

    def redo(self):
        if self.undo_manager is None:
            return
        if self.undo_manager.redo():
            self.statusBar().showMessage("Redo")
        else:
            self.statusBar().showMessage("Nothing to redo.")

def main():
    app = QApplication([])
    window = MainWindow()
    window.show()
    app.exec()


if __name__ == "__main__":
    main()