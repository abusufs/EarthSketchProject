"""
UserGuide.py
Interactive in-application user guide. Opened from the "User Guide" button in
the sidebar, or by pressing F1. Topics are listed on the left; selecting one
shows its content on the right, so the user can browse rather than read a wall
of text (recognition rather than recall).
"""

from PySide6.QtWidgets import (
    QDialog,
    QHBoxLayout,
    QVBoxLayout,
    QListWidget,
    QTextBrowser,
    QPushButton,
    QLabel,
)
from PySide6.QtCore import Qt


# Each topic is (title, html_body). Keeping this as plain data makes it easy
# for the team to add sections without touching the widget code.
GUIDE_TOPICS = [
    ("Getting started", """
        <h2>Getting started</h2>
        <p>EarthSketch 3D lets you load a landscape, inspect its soil, and paint
        soil type and depth directly onto the terrain in 3D.</p>
        <ol>
          <li>Click <b>Load Terrain</b> and pick an <code>.elv</code> file
              (samples live in the <code>data/</code> folder).</li>
          <li>Or click <b>Generate New Terrain</b> to create one procedurally.</li>
          <li>Drag with the left mouse button to orbit; scroll to zoom.</li>
          <li>Pick a soil type under <b>Tool</b>, set a <b>Brush Size</b>, then
              paint on the surface.</li>
          <li>Click <b>Save Terrain</b> to write elevation <i>and</i> soil data
              back out to a file.</li>
        </ol>
        <p>The status bar at the bottom of the window always reports what the
        application is currently doing.</p>
    """),

    ("Loading and saving", """
        <h2>Loading and saving</h2>
        <p><b>Load Terrain</b> accepts two file layouts, and detects which one
        it is given automatically:</p>
        <ul>
          <li><b>Elevation only</b> &mdash; a header line
              (<code>width height spacing latitude</code>) followed by the
              elevation grid. Soil type and depth are then initialised
              automatically from the terrain shape.</li>
          <li><b>Full terrain</b> &mdash; the same header, then
              <code>BAND:</code> sections for elevation, sand, silt, clay and
              depth. This is what <b>Save Terrain</b> writes, so anything you
              paint survives a save/reload cycle.</li>
        </ul>
        <p>Terrains do not have to be square, and their dimensions do not have
        to be powers of two.</p>
        <p>If a file is malformed &mdash; wrong value count, non-numeric data, a
        bad header &mdash; loading stops and an error message names the problem
        instead of leaving you with a half-loaded terrain.</p>
    """),

    ("Moving the camera", """
        <h2>Moving the camera</h2>
        <table cellpadding="4">
          <tr><td><b>Right-click + drag</b></td><td>Orbit around the terrain</td></tr>
          <tr><td><b>Scroll wheel</b></td><td>Zoom in and out</td></tr>
          <tr><td><b>Middle-click + drag</b></td><td>Pan the view</td></tr>
        </table>
        <p>Orbiting is the quickest way to check the soil-depth nails beneath
        the terrain block &mdash; look at it from a low angle.</p>
    """),

    ("Painting soil", """
        <h2>Painting soil</h2>
        <p>Choose what you are painting under <b>Tool</b>, then click and drag
        on the terrain surface. The brush affects a circular area around the
        cursor.</p>
        <ul>
          <li><b>Brush Size</b> sets the radius of that circle, in grid cells.</li>
          <li><b>Brush Strength</b> sets how strongly each stroke pushes the
              soil mix toward the selected type.</li>
        </ul>
        <p>Painting updates the surface colour immediately &mdash; only the
        cells under the brush are recoloured, which is what keeps painting
        responsive on large terrains.</p>
    """),

    ("Reading the colours", """
        <h2>Reading the colours</h2>
        <p>The terrain surface colour encodes the <b>soil type mix</b> at each
        cell, blended from three channels:</p>
        <ul>
          <li><b>Red</b> &mdash; proportion of sand</li>
          <li><b>Green</b> &mdash; proportion of silt</li>
          <li><b>Blue</b> &mdash; proportion of clay</li>
        </ul>
        <p>A cell that is pure sand appears red; an even mix appears greyish.
        Because real terrain is rarely one pure type, most of the surface shows
        a blend.</p>
        <p>Colour shows soil <i>type</i> only. Soil <i>depth</i> is a separate
        thing, shown by the nails &mdash; see the next topic.</p>
    """),

        ("Soil depth (bed of nails)", """
        <h2>Soil depth (bed of nails)</h2>
        <p>Soil depth is shown as a grid of pins hanging down from the terrain
        surface. Each pin sits at its own grid location, and its
        <b>length is proportional to the soil depth</b> at that point.</p>
        <p>Use the <b>Soil Depth View</b> panel in the sidebar to see them:</p>
        <ul>
          <li><b>Show bed of nails</b> toggles the pins on and off. When it's
              on, the terrain surface and the block beneath it turn translucent
              so the pins are visible inside &mdash; turn it off to go back to
              the solid, opaque soil-type view.</li>
          <li><b>Depth exaggeration</b> controls how tall the pins are drawn, as
              a percentage of the terrain's own height. This exists because
              real soil depth is under a metre on terrain that can be hundreds
              of metres tall &mdash; drawn at true scale the pins would be
              invisible, so they're stretched to a visible size.</li>
        </ul>
        <p>The colour scale beside the viewport, labelled <b>Soil depth (m)</b>,
        always reads <i>true</i> depth in metres regardless of how the
        exaggeration slider is set &mdash; only the drawn pin length changes,
        never the value it represents.</p>
    """),

    ("Default soil initialisation", """
        <h2>Default soil initialisation</h2>
        <p>When a terrain is loaded without soil data, soil type and depth are
        not set to flat constants. They are derived from the shape of the
        terrain itself:</p>
        <ul>
          <li><b>Steep ground</b> holds less sand. Loose dry sand cannot rest on
              slopes past its angle of repose, so sand falls off as slope
              increases and the finer, more cohesive silt and clay make up the
              difference.</li>
          <li><b>Steep ground</b> also carries thinner soil, because material is
              continually eroded off it.</li>
          <li><b>Local hollows</b> carry deeper soil, because eroded material
              accumulates where the ground dips relative to its surroundings.</li>
        </ul>
        <p>You can see this directly: ridgelines and steep faces read differently
        from valley floors before you paint anything at all.</p>
    """),

    ("Troubleshooting", """
        <h2>Troubleshooting</h2>
        <p><b>A file will not load.</b> The error message names the line and the
        problem. Most often the value count does not match the
        <code>width height</code> stated in the header.</p>
        <p><b>Painting does nothing.</b> Make sure a terrain is loaded, and that
        you are clicking on the terrain surface rather than the empty
        background.</p>
        <p><b>I cannot see the depth nails.</b> Orbit down to a low angle &mdash;
        they hang beneath the solid terrain block, so a top-down view hides
        them.</p>
        <p><b>Saving reports an error.</b> Check that you have write permission
        for the folder you chose, and that the terrain finished loading first.</p>
    """),
]


class UserGuideDialog(QDialog):
    """Browsable, non-modal user guide."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("EarthSketch 3D - User Guide")
        self.resize(760, 520)

        layout = QVBoxLayout()

        header = QLabel("Select a topic to learn how that part of EarthSketch works.")
        header.setWordWrap(True)
        layout.addWidget(header)

        body = QHBoxLayout()

        self.topicList = QListWidget()
        self.topicList.setFixedWidth(210)
        for title, _ in GUIDE_TOPICS:
            self.topicList.addItem(title)
        body.addWidget(self.topicList)

        self.content = QTextBrowser()
        self.content.setOpenExternalLinks(True)
        body.addWidget(self.content, 1)

        layout.addLayout(body)

        self.btnClose = QPushButton("Close")
        self.btnClose.clicked.connect(self.close)
        layout.addWidget(self.btnClose, alignment=Qt.AlignRight)

        self.setLayout(layout)

        self.topicList.currentRowChanged.connect(self.show_topic)
        self.topicList.setCurrentRow(0)

    def show_topic(self, index: int) -> None:
        if 0 <= index < len(GUIDE_TOPICS):
            self.content.setHtml(GUIDE_TOPICS[index][1])

    def show_topic_by_title(self, title: str) -> None:
        """Jump straight to a named topic, e.g. from a context-sensitive button."""
        for i, (topic_title, _) in enumerate(GUIDE_TOPICS):
            if topic_title == title:
                self.topicList.setCurrentRow(i)
                return
