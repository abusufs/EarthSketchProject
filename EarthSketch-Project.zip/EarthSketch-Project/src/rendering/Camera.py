"""
Camera.py - 3D camera controls using PyVista.
Purpose: Allow the user to rotate, zoom, and pan around the terrain.
"""

import pyvista as pv
import numpy as np
from typing import Optional
from ..core.Terrain import Terrain  


class Camera:
    """
    Wraps a PyVista plotter's camera to provide high-level orbital controls.
    """

    def __init__(self, plotter: pv.Plotter) -> None:
        """
        Initialise the camera controller with a PyVista plotter.

        Args:
            plotter: The PyVista render window (or QtInteractor) we control.
        """
        self.plotter = plotter
        # Internal reference to PyVista's native camera object.
        self._camera = plotter.camera

    # Private Helper Methods

    def _apply_and_render(self) -> None:
        """
        Push the current camera settings to the plotter and redraw the scene.
        This is called after every orbit, zoom, pan, or reset operation.
        """
        self.plotter.camera = self._camera
        self.plotter.render()

    # Public Control Methods

    def focus_on_terrain(self, terrain: Terrain) -> None:
        """
        Automatically position the camera to perfectly view the given terrain.

        This calculates the center point (average X, Y, and elevation) and sets
        the distance based on the terrain's physical size.

        Args:
            terrain: The Terrain object to focus on.
        """
        # Calculate the physical width and height of the terrain in meters.
        physical_width = terrain.width * terrain.spacing
        physical_height = terrain.height * terrain.spacing

        # Compute the center coordinates.
        center_x = physical_width / 2.0
        center_y = physical_height / 2.0

        # Compute the average elevation to set the focal point's Z correctly.
        flat_elevations = [val for row in terrain.elevations for val in row]
        center_z = sum(flat_elevations) / len(flat_elevations)

        # The focal point is the exact 3D point we want to look at.
        focal_point = np.array([center_x, center_y, center_z])

        # Set the distance based on the terrain size (add a 20% margin).
        max_dimension = max(physical_width, physical_height)
        distance = max_dimension * 0.8  # 0.8 multiplier gives a nice framing

        # Define the default view angles (45° azimuth, 30° elevation).
        azimuth_rad = np.radians(45.0)
        elevation_rad = np.radians(30.0)

        # Convert spherical coordinates to Cartesian to place the camera.
        offset_x = distance * np.cos(elevation_rad) * np.sin(azimuth_rad)
        offset_y = distance * np.cos(elevation_rad) * np.cos(azimuth_rad)
        offset_z = distance * np.sin(elevation_rad)

        # The camera position is the focal point plus the offset.
        position = focal_point + np.array([offset_x, offset_y, offset_z])

        # Apply the settings to the internal camera.
        self._camera.position = tuple(position)
        self._camera.focal_point = tuple(focal_point)
        self._camera.up = (0.0, 0.0, 1.0)  # Z-axis is "up" in our world.

        self._apply_and_render()

    def orbit(self, delta_azimuth_deg: float, delta_elevation_deg: float) -> None:
        """
        Rotate the camera around the focal point.

        Args:
            delta_azimuth_deg: Horizontal mouse movement (in degrees).
            delta_elevation_deg: Vertical mouse movement (in degrees).
        """
        # Get the current position and focal point.
        position = np.array(self._camera.position)
        focal_point = np.array(self._camera.focal_point)

        # Vector from focal point to camera.
        vector_from_center = position - focal_point
        # Distance (radius) from focal point.
        radius = np.linalg.norm(vector_from_center)

        # Convert the vector to spherical coordinates (angles in radians).
        azimuth = np.arctan2(vector_from_center[0], vector_from_center[1])
        elevation = np.arcsin(vector_from_center[2] / radius)

        # Apply the mouse delta (convert input degrees to radians).
        azimuth += np.radians(delta_azimuth_deg)
        elevation += np.radians(delta_elevation_deg)

        # Clamp elevation to prevent the camera from flipping upside down.
        # We keep it just inside the -90° and +90° range.
        max_elevation = np.pi / 2.0 - 0.01
        min_elevation = -np.pi / 2.0 + 0.01
        elevation = np.clip(elevation, min_elevation, max_elevation)

        # Convert the new spherical angles back to Cartesian coordinates.
        offset_x = radius * np.cos(elevation) * np.sin(azimuth)
        offset_y = radius * np.cos(elevation) * np.cos(azimuth)
        offset_z = radius * np.sin(elevation)

        # Compute the new absolute position.
        new_position = focal_point + np.array([offset_x, offset_y, offset_z])

        # Update the camera.
        self._camera.position = tuple(new_position)
        self._camera.focal_point = tuple(focal_point)  # Focal point stays fixed.
        self._apply_and_render()

    def zoom(self, amount: float) -> None:
        """
        Move the camera closer to or farther from the focal point.

        Args:
            amount: Positive value moves camera closer (zoom in).
                    Negative value moves camera farther (zoom out).
        """
        position = np.array(self._camera.position)
        focal_point = np.array(self._camera.focal_point)

        # Direction vector from focal point to camera.
        direction = position - focal_point
        current_distance = np.linalg.norm(direction)

        # Avoid division by zero.
        if current_distance < 1e-6:
            return

        # Calculate the new distance. 'amount' is scaled by 0.1 for smooth control.
        scale_factor = 1.0 - amount * 0.1
        new_distance = current_distance * scale_factor

        # Prevent the camera from crossing through the focal point.
        new_distance = max(new_distance, 1.0)

        # Compute the new position by moving along the direction vector.
        unit_direction = direction / current_distance
        new_position = focal_point + (unit_direction * new_distance)

        self._camera.position = tuple(new_position)
        # Focal point remains unchanged.
        self._apply_and_render()

    def pan(self, delta_x: float, delta_y: float) -> None:
        """
        Slide the camera and focal point together (like dragging the ground).

        Args:
            delta_x: Horizontal pan amount (in arbitrary screen units).
            delta_y: Vertical pan amount (in arbitrary screen units).
        """
        position = np.array(self._camera.position)
        focal_point = np.array(self._camera.focal_point)
        up_vector = np.array(self._camera.up)

        # View direction (from focal point to camera).
        view_vector = position - focal_point
        view_distance = np.linalg.norm(view_vector)
        view_unit = view_vector / view_distance

        # Calculate the "right" vector (perpendicular to view and up).
        right_vector = np.cross(view_unit, up_vector)
        # If view is perfectly aligned with up, use a fallback.
        if np.linalg.norm(right_vector) < 1e-6:
            right_vector = np.array([1.0, 0.0, 0.0])
        right_unit = right_vector / np.linalg.norm(right_vector)

        # Calculate the camera's local "up" direction (perpendicular to view and right).
        local_up_unit = np.cross(right_unit, view_unit)

        # Scale the pan speed based on distance (so panning feels consistent).
        pan_speed = view_distance * 0.01

        # Calculate the translation offset.
        offset = (delta_x * right_unit + delta_y * local_up_unit) * pan_speed

        # Move both the camera and the focal point by the same offset.
        new_focal_point = focal_point + offset
        new_position = position + offset

        self._camera.focal_point = tuple(new_focal_point)
        self._camera.position = tuple(new_position)
        self._apply_and_render()

    def reset(self) -> None:
        """
        Reset the camera to a fixed default position relative to the current focal point.
        This places the camera 150 units away at a 45° azimuth and 30° elevation.
        """
        if self._camera.focal_point is not None:
            focal_point = np.array(self._camera.focal_point)
        else:
            focal_point = np.array([0.0, 0.0, 0.0])

        distance = 150.0
        azimuth_rad = np.radians(45.0)
        elevation_rad = np.radians(30.0)

        offset_x = distance * np.cos(elevation_rad) * np.sin(azimuth_rad)
        offset_y = distance * np.cos(elevation_rad) * np.cos(azimuth_rad)
        offset_z = distance * np.sin(elevation_rad)

        new_position = focal_point + np.array([offset_x, offset_y, offset_z])

        self._camera.position = tuple(new_position)
        self._camera.focal_point = tuple(focal_point)
        self._camera.up = (0.0, 0.0, 1.0)  # Ensure Z remains "up".
        self._apply_and_render()

    # Optional: These methods are usually handled by PyVista internally,
    # but we provide them for completeness if you ever write custom shaders.
    def get_view_matrix(self) -> np.ndarray:
        """Return the 4x4 view matrix (look-at matrix)."""
        return self._camera.view_matrix

    def get_projection_matrix(self) -> np.ndarray:
        """Return the 4x4 projection matrix (perspective)."""
        return self._camera.projection_matrix