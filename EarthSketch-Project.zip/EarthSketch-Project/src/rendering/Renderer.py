""" Renderer.py
    Managing the PyVista mesh and its visual appearance.
"""

import pyvista as pv # 3D rendering interface
import numpy as np # fast arr computation
from typing import Optional,Literal # allows for easy visual representstion
from ..core.Terrain import Terrain # Terrain obj
from pyvistaqt import QtInteractor #Qt widget for plotting

COLOUR_MODES =Literal["soil","depth"]

class Renderer:
    """ Managing the PyVista mesh and its visual appearance. """

    def __init__(self,parent = None):
        self.plot = QtInteractor(parent) # 3D placeholder
        self.terrain: Optional[Terrain] = None # if not terrain then none
        self.mesh: Optional[pv.PolyData] = None # 3d data net made of  squares & points
        self.actor: Optional[pv.Actor] = None # actor=deafault model
        self.base_mesh: Optional[pv.PolyData] = None 
        self.base_actor: Optional[pv.Actor] = None 
        self.nails_mesh: Optional[pv.PolyData] = None
        self.nails_actor: Optional[pv.Actor] = None
        self.colour_mode :COLOUR_MODES = "soil"
        
        self.show_depth: bool = True          # bed-of-nails view on by default
        self.depth_exaggeration: float = 0.15  # deepest pin = 15% of terrain relief
        self.nail_density: int = 45            # approx. pins per axis

    @property
    def interactor(self):
        return self.plot.interactor

    
    def set_terrain(self, terrain: Terrain) -> None:
        self.terrain = terrain
        # use elements of terrain to develop the rest
        self._build_mesh()
        self._build_base()
        self._build_nails()
        self._update_colours()
        self._add_to_plot()

    def _build_mesh(self) -> None:
        
        if self.terrain is None:
            return

        width = self.terrain.width
        height = self.terrain.height
        spacing = self.terrain.spacing
        elev = np.array(self.terrain.elevations, dtype=np.float32)

        x_list = np.arange(width) * spacing
        y_list = np.arange(height) * spacing
        xx, yy = np.meshgrid(x_list, y_list, indexing='xy')
        z = elev

        points = np.stack([xx, yy, z], axis=-1).reshape(-1, 3)

        # Vectorized replacement for the old row/col Python loop.
        rows = np.arange(height - 1, dtype=np.int64)[:, None]
        cols = np.arange(width - 1, dtype=np.int64)[None, :]
        idx = (rows * width + cols).ravel()   # top-left index of every cell, row-major

        n_quads = idx.size
        squares = np.empty((n_quads, 5), dtype=np.int64)
        squares[:, 0] = 4                  # VTK "4 points in this face" marker
        squares[:, 1] = idx                # i0: top-left
        squares[:, 2] = idx + 1            # i1: top-right
        squares[:, 3] = idx + width + 1    # i3: bottom-right
        squares[:, 4] = idx + width        # i2: bottom-left
        squares = squares.reshape(-1)

        self.mesh = pv.PolyData(points, squares)

    def _build_base(self) -> None:
        """Solid opaque block beneath the terrain surface.

        Built as a boundary 'skirt' (4 walls + bottom) rather than extruding the
        whole mesh: the block's interior is never visible, so extruding a
        million cells to produce it was pure wasted work.
        """
        if self.terrain is None or self.mesh is None:
            return

        width = self.terrain.width
        height = self.terrain.height
        spacing = self.terrain.spacing
        elev = np.asarray(self.terrain.elevations, dtype=np.float32)

        relief = float(elev.max() - elev.min())
        base_z = float(elev.min()) - max(5.0, 1.2 * self.depth_exaggeration * relief)

        xs = np.arange(width, dtype=np.float32) * spacing
        ys = np.arange(height, dtype=np.float32) * spacing

        def wall(x_line, y_line, z_line):
            """One quad strip running along an edge, from surface down to base_z."""
            n = len(z_line)
            top = np.stack([x_line, y_line, z_line], axis=-1)
            bot = np.stack([x_line, y_line, np.full(n, base_z, dtype=np.float32)], axis=-1)
            pts = np.vstack([top, bot]).astype(np.float32)
            i = np.arange(n - 1)
            faces = np.stack([np.full(n - 1, 4), i, i + 1, i + 1 + n, i + n], axis=-1).reshape(-1)
            return pv.PolyData(pts, faces)

        south = wall(xs, np.full(width, ys[0], dtype=np.float32), elev[0, :])
        north = wall(xs, np.full(width, ys[-1], dtype=np.float32), elev[-1, :])
        west = wall(np.full(height, xs[0], dtype=np.float32), ys, elev[:, 0])
        east = wall(np.full(height, xs[-1], dtype=np.float32), ys, elev[:, -1])

        bottom_pts = np.array([
            [xs[0], ys[0], base_z], [xs[-1], ys[0], base_z],
            [xs[-1], ys[-1], base_z], [xs[0], ys[-1], base_z],
        ], dtype=np.float32)
        bottom = pv.PolyData(bottom_pts, np.array([4, 0, 1, 2, 3]))

        self.base_mesh = south + north + west + east + bottom

    def _build_nails(self) -> None:
        """Bed-of-nails soil-depth visualization: a pin dropped from the terrain
        surface at each sampled cell, length proportional to that cell's soil
        depth. Seen through the translucent shell in Depth View."""
        if self.terrain is None or self.mesh is None:
            return

        width, height, spacing = self.terrain.width, self.terrain.height, self.terrain.spacing
        elev = np.asarray(self.terrain.elevations, dtype=np.float32)
        depth = np.asarray(self.terrain.depth, dtype=np.float32)

        # Fixed pin count per axis regardless of terrain size: reads as a bed
        # without turning into a solid wall on a 1024x1024 terrain.
        stride = max(1, max(width, height) // self.nail_density)
        rows = np.arange(0, height, stride)
        cols = np.arange(0, width, stride)
        rr, cc = np.meshgrid(rows, cols, indexing='ij')

        # Soil depth is sub-metre; relief is hundreds of metres. Without
        # exaggeration the pins are sub-pixel, so scale the deepest pin to a
        # set fraction of relief. The colour bar still reports true depths.
        relief = float(elev.max() - elev.min())
        max_depth = float(depth.max())
        exaggeration = (self.depth_exaggeration * relief / max_depth) if max_depth > 0 else 1.0

        # Anchor each pin at the terrain surface and hang it downward.
        points = np.stack([
            cc * spacing,
            rr * spacing,
            elev[rr, cc],
        ], axis=-1).reshape(-1, 3)

        cloud = pv.PolyData(points.astype(np.float32))
        cloud["depth"] = depth[rr, cc].reshape(-1).astype(np.float32)

        nail_template = pv.Line((0, 0, 0), (0, 0, -exaggeration))
        # No .tube() — thick GPU lines are far cheaper than real tube geometry.
        self.nails_mesh = cloud.glyph(orient=False, scale="depth", factor=1.0, geom=nail_template)

    def set_colour_mode(self,colourmode:COLOUR_MODES)->None:
        if colourmode not in ("soil","depth"):
            raise ValueError(f"Colour mode must be 'soil' or 'depth', got {colourmode!r}")
        if colourmode==self.colour_mode:
            return
        self.colour_mode=colourmode
        self.update_colours()

    def _depth_ramp_colours(self, depth_slice: np.ndarray, d_min: float, d_max: float) -> np.ndarray:
        """Map depth values to a single-hue contrast ramp: dark teal (shallow) -> bright cyan (deep)."""
        span = d_max - d_min
        t = (depth_slice - d_min) / span if span > 1e-9 else np.zeros_like(depth_slice)
        base = np.array([0.05, 0.35, 0.45], dtype=np.float32)   # dark teal, shallow
        peak = np.array([0.35, 0.95, 1.00], dtype=np.float32)   # bright cyan, deep
        return base[None, None, :] * (1 - t[..., None]) + peak[None, None, :] * t[..., None]
    
    def _compute_face_colours(self) -> np.ndarray:
        if self.terrain is None:
            return np.empty((0, 3), dtype=np.float32)

        if self.colour_mode == "soil":
            sand = np.array(self.terrain.sand, dtype=np.float32)
            silt = np.array(self.terrain.silt, dtype=np.float32)
            clay = np.array(self.terrain.clay, dtype=np.float32)

            # use top-left corner of each cell, vectorized over the whole grid
            colours = np.stack([sand[:-1, :-1], silt[:-1, :-1], clay[:-1, :-1]], axis=-1) / 100.0
            return colours.reshape(-1, 3).astype(np.float32)
        else:
            depth = np.array(self.terrain.depth, dtype=np.float32)
            d_min, d_max = float(depth.min()), float(depth.max())
            colours = self._depth_ramp_colours(depth[:-1, :-1], d_min, d_max)
            return colours.reshape(-1, 3).astype(np.float32)

    def _update_colours(self) -> None:
        if self.mesh is None or self.terrain is None:
            return
        colours = self._compute_face_colours() # compute colours fast
        self.mesh.cell_data['RGB'] = colours  

    def update_colours(self) -> None:
        
        self._update_colours()
        
        if self.actor is not None:
            self.plot.render()

    def update_colours_region(self, row_min: int, row_max: int, col_min: int, col_max: int) -> None:
        """Update cell RGB data only for the affected rows/cols (col_max/row_max exclusive)."""
        if self.mesh is None or self.terrain is None:
            return

        width = self.terrain.width
        height = self.terrain.height

        # Clamp
        r0 = max(0, row_min)
        r1 = min(row_max, height - 1)   # cell grid has height-1 rows
        c0 = max(0, col_min)
        c1 = min(col_max, width - 1)    # cell grid has width-1 cols

        if r0 >= r1 or c0 >= c1:
            return

        if self.colour_mode=="soil":
            # Slice the Python lists first (cheap), THEN convert only that slice to numpy
            sand = np.array([row[c0:c1] for row in self.terrain.sand[r0:r1]], dtype=np.float32)
            silt = np.array([row[c0:c1] for row in self.terrain.silt[r0:r1]], dtype=np.float32)
            clay = np.array([row[c0:c1] for row in self.terrain.clay[r0:r1]], dtype=np.float32)
            region = (np.stack([sand, silt, clay], axis=-1) / 100.0).astype(np.float32)
        else:
            depth_full =np.asarray(self.terrain.depth,dtype=np.float32)
            depth_min,depth_max=float(depth_full.min()),float(depth_full.max())
            depth_region = np.array([row[c0:c1] for row in self.terrain.depth[r0:r1]], dtype=np.float32)
            region = self._depth_ramp_colours(depth_region,depth_min,depth_max).astype(np.float32)
            

        

        row_width = c1 - c0
        region = region.reshape(-1, 3)
        
        
        rgb = self.mesh.cell_data['RGB']
        cells_per_row = width - 1
        for i, row in enumerate(range(r0, r1)):
            idx0 = row * cells_per_row + c0
            idx1 = idx0 + row_width
            rgb[idx0:idx1] = region[i * row_width:(i + 1) * row_width]

        if self.actor is not None:
            self.plot.render()    
            
    def set_depth_visible(self, visible: bool) -> None:
        """Switch between the solid soil-type view and the see-through depth view."""
        self.show_depth = bool(visible)
        self._add_to_plot()

    def set_depth_exaggeration(self, fraction_of_relief: float) -> None:
        """Set how tall the deepest pin is drawn, as a fraction of terrain relief."""
        self.depth_exaggeration = max(0.01, float(fraction_of_relief))
        self._build_base()
        self._build_nails()
        self._add_to_plot()  

    def _add_to_plot(self) -> None:
        if self.mesh is None:
            return

        for attr in ("actor", "base_actor", "nails_actor"):
            existing = getattr(self, attr)
            if existing is not None:
                self.plot.remove_actor(existing)
                setattr(self, attr, None)

        # Actors carry their scalar bar with them; drop it so it doesn't linger
        # after the nails are hidden.
        try:
            self.plot.remove_scalar_bar("Soil depth (m)")
        except Exception:
            pass

        if self.base_mesh is None:
            return

        if self.show_depth and self.nails_mesh is not None:
            # Opaque pins go in first; the translucent shell is drawn over them.
            self.nails_actor = self.plot.add_mesh(
                self.nails_mesh,
                scalars="depth",
                cmap="turbo",
                line_width=5,
                render_lines_as_tubes=True,
                scalar_bar_args={"title": "Soil depth (m)"},
            )
            surface_opacity = 0.45
            base_opacity = 0.30
        else:
            surface_opacity = 1.0
            base_opacity = 1.0

        self.actor = self.plot.add_mesh(
            self.mesh, scalars='RGB', rgb=True, show_edges=False,
            smooth_shading=True, opacity=surface_opacity,
        )

        self.base_actor = self.plot.add_mesh(
            self.base_mesh, color='#6b4a2f', show_edges=False,
            smooth_shading=False, opacity=base_opacity,
        )

        self.plot.render()

    def update_elevations(self) -> None:
        if self.terrain is None:
            return
        
        if self.actor is not None:
            self.plot.remove_actor(self.actor)
            self.actor = None
        if self.base_actor is not None:
            self.plot.remove_actor(self.base_actor)
            self.base_actor = None
        if self.nails_actor is not None:
            self.plot.remove_actor(self.nails_actor)
            self.nails_actor = None
            
        self.mesh = None
        self.base_mesh = None
        self.nails_mesh = None
        self._build_mesh()
        self._build_base()
        self._build_nails()
        self._update_colours()
        self._add_to_plot()

# clear rendered view
    def clear_terrain(self) -> None:
        if self.actor is not None:
            self.plot.remove_actor(self.actor)
            self.actor = None
        if self.base_actor is not None:
            self.plot.remove_actor(self.base_actor)
            self.base_actor = None
        if self.nails_actor is not None:
            self.plot.remove_actor(self.nails_actor)
            self.nails_actor = None
        self.terrain = None
        self.mesh = None
        self.base_mesh = None
        self.nails_mesh = None
        self.plot.render()