"""
Handles applying soil type to terrain cells.
"""

from typing import Literal, Tuple,Optional, List

# Imports from our packages
from ..core.Terrain import Terrain
from .RayCast import RaycastHit
from ..core.SoilValidator import SoilValidator
import numpy as np



PAINT_MODES = Literal["soil","depth"]
EFFECT_MODES = Literal["constant", "gaussian", "intelligent"]
DEPTH_EDIT_MODES = Literal["set", "add", "subtract"]



class Brush:
    """
    Represents a painting brush that modifies soil composition on a Terrain object.
    """

    def __init__(self, terrain: Terrain, size: int = 1) -> None:
        self.terrain = terrain
        self.size = size
        self.soilTarget: Tuple[float, float, float] = self.terrain.get_soil_texture(0,0)

        self.paintMode: PAINT_MODES  = "soil"
        self.effectType: EFFECT_MODES = "constant"
        self.depthEditMode: DEPTH_EDIT_MODES = "add"
        self.depthValue: float = 1.0
        self.depthDelta: float = 0.1

        self._weight_cache: Optional[np.ndarray] =None
        self._weight_radius: Optional[int] =None

    def set_size(self, size: int)-> None:
        """Sets the brush size."""

        #check size
        if size < 1:
            raise ValueError("Brush size must be at least 1.")

        self.size = size

    def set_custom_soil(self, sand: float, silt: float, clay: float) -> None:
        """Paint with an arbitrary sand/silt/clay blend instead of a pure preset."""
        SoilValidator.validate_soil_percentages(sand, silt, clay)
        self.soilTarget = (sand, silt, clay)
        
    def set_depth_value(self, depth: float) -> None:

        self.depthValue = max(depth,0.0)

    def set_paint_mode(self,mode: PAINT_MODES) -> None:
        self.paintMode = mode

    def set_effect_type(self, effect: EFFECT_MODES) -> None:
        if effect not in ("constant", "gaussian", "intelligent"):
            raise ValueError("Effect type must be 'constant', 'gaussian' or 'intelligent'.")
        self.effectType = effect

    def set_depth_mode(self, mode: DEPTH_EDIT_MODES) -> None:
        if mode not in ("set", "add", "subtract"):
            raise ValueError("Depth edit mode must be 'set', 'add' or 'subtract'.")
        self.depthEditMode = mode


    def set_depth_delta(self, delta: float) ->None:
        self.depthDelta =max(0.0,delta)


    def _get_weights(self, radius: int, center_row: int, center_col: int) -> np.ndarray:
        dr, dc = np.ogrid[-radius:radius+1, -radius:radius+1]
        dist_sq = dr*dr + dc*dc
        circle = dist_sq <= radius*radius

        if self.effectType == "constant":
            return circle.astype(np.float32)

        if self.effectType == "gaussian":
            sigma = max(radius / 2.0, 1e-3)
            weights = np.exp(-dist_sq / (2 * sigma**2)).astype(np.float32)
            weights[~circle] = 0.0
            return weights

        
        return self._intelligent_weights(radius, center_row, center_col, circle)

    def _intelligent_weights(self, radius, center_row, center_col, circle) -> np.ndarray:
        sigma = max(radius / 2.0, 1e-3)
        dr, dc = np.ogrid[-radius:radius+1, -radius:radius+1]
        dist_sq = dr*dr + dc*dc
        base = np.exp(-dist_sq / (2 * sigma**2)).astype(np.float32)

        row_min, row_max = center_row - radius, center_row + radius + 1
        col_min, col_max = center_col - radius, center_col + radius + 1

        
        full_grad = self.terrain.get_gradient_magnitude()  # cache this per-stroke if slow
        r0, r1 = max(0, row_min), min(row_max, self.terrain.height)
        c0, c1 = max(0, col_min), min(col_max, self.terrain.width)

        grad_region = np.zeros_like(base)
        if r1 > r0 and c1 > c0:
            grad_region[r0 - row_min:r1 - row_min, c0 - col_min:c1 - col_min] = \
                full_grad[r0:r1, c0:c1]

        # Steeper slope is less effect. Normalize by a soft scale so units don't blow up.
        slope_factor = 1.0 / (1.0 + grad_region * 5.0) 
        weights = base * slope_factor
        weights[~circle] = 0.0
        return weights
    
    def _get_circle_mask(self, radius: int) -> np.ndarray:
        """Boolean footprint, shaped (2*radius+1, 2*radius+1) — used for depth edits, which are on/off, not blended."""
        dr, dc = np.ogrid[-radius:radius + 1, -radius:radius + 1]
        return (dr * dr + dc * dc) <= radius * radius

    def paint(self, hit: RaycastHit) -> List[Tuple[int, int, Tuple[float, float, float], Tuple[float, float, float]]]:
        """
        Paint the terrain in a circular area around the clicked location.
        Returns a list of (row, col, before_soil, after_soil) for every cell
        actually painted, so callers can build undo history.
        """
        center_row = hit.cell_row
        center_col = hit.cell_col
        radius = self.size // 2
        row_min, row_max = center_row - radius, center_row + radius + 1
        col_min, col_max = center_col - radius, center_col + radius + 1

        r0, r1 = max(0, row_min), min(row_max, self.terrain.height)
        c0, c1 = max(0, col_min), min(col_max, self.terrain.width)
        if r0 >= r1 or c0 >= c1:
            return None

        if self.paintMode == "soil":
            weights = self._get_weights(radius, center_row, center_col)
            self._paint_soil(row_min, row_max, col_min, col_max, weights)
        else:  # "depth"
            weights = self._get_weights(radius, center_row, center_col)
            self._paint_depth(row_min, row_max, col_min, col_max, weights)

        return (r0, r1, c0, c1)

    
    def _paint_soil(self,row_min,row_max,col_min,col_max,weights)->None:
       
        sand_t,silt_t,clay_t = self.soilTarget

        for array,target in (
            (self.terrain.sand, sand_t),
            (self.terrain.silt, silt_t),
            (self.terrain.clay, clay_t),
        ):
            
            self.terrain.apply_weighted_update(array, row_min, row_max, col_min, col_max, weights, target)

    def _paint_depth(self,row_min,row_max,col_min,col_max,weights)->None:
        if self.depthEditMode == "set":
            value = self.depthValue
            fn = lambda current,w: current *(1-w)+value*w
        elif self.depthEditMode == "add":
            delta = self.depthDelta
            fn = lambda current,w: np.clip(current+delta*w,0,None)
        else:
            delta =self.depthDelta
            fn = lambda current,w: np.clip(current-delta*w,0,None)
        self.terrain.apply_weighed_depth_update(self.terrain.depth, row_min,row_max,col_min,col_max,weights,update_fn = fn)


    