from typing import Optional,Tuple
from dataclasses import dataclass
import pyvista as pv
from ..core.Terrain import Terrain
import numpy as np
import math


@dataclass
class RaycastHit:
    """Stores result if terrain was picked successfulling"""
    world_position: Tuple[float, float, float]
    cell_row: int
    cell_col: int

class RayCast:
    """
    Wraps PyVista's picking so the rest of the program doesnt have to talk to PyVista directly. 
    Converts a screen click into a terrain grid coordinates
    """
    def __init__(self, plotter: pv.plotter,  cell_spacing: float, terrain: Terrain, grid_origin: Tuple[float,float] = (0,0)):
        self._plotter = plotter #pyvista object that is rendering things and recieving mouse clicks
        
        self._origin = grid_origin #point of origin on grid [0,0]
        self._spacing = cell_spacing #space between cells
        
        self._terrain = terrain
        width,height = self._terrain.getDimensions()
        self._elev = terrain.get_elevation_grid_numpy()
        self._height = terrain.height
        self._width = terrain.width
        self._box_min = np.array([0.0, 0.0, self._elev.min()])
        self._box_max = np.array([(width-1)*self._spacing, (height-1)*self._spacing, self._elev.max()])

    def pick_at_screen(self, x: int, y: int) -> Optional[RaycastHit]:
        """
        guive whatever is under the given screen pixel and convert to grid points

        called by MainWindow on mouse press/move while painting
        """
        origin,direction =self._screen_to_ray(x,y)
        world_point = self._intersect_heightfield(origin, direction)
        return self._world_to_hit(world_point) if world_point is not None else None
    

    def _world_to_hit(self,world_point) ->Optional[RaycastHit]:
        """
        converts the point click coords to points on the terrain grid and returns the RayCasthit
        """
        x,y,z = world_point #point that is clicked
        #converts to points on the grid
        col = round((x-self._origin[0]) / self._spacing) 
        row = round((y-self._origin[1]) / self._spacing) #calculating grid indices

        dim = self._terrain.getDimensions() #terrain grid bounds


        #check they are on the grid
        if row<0 or col < 0 or col >= dim[0] or row >= dim[1]:
            return None
            
            

        #return raycasthit
        return RaycastHit(
            world_position=(x, y, z),
            cell_row=row,
            cell_col=col,
        ) 

    
    def pick_at_ray(self,origin, direction):
        """
        alternative ray-tracing hit test that casts straight line from a 3d origin point to see
        where ot hits the target
        """
        world_point = self._intersect_heightfield(origin, direction)
        return self._world_to_hit(world_point) if world_point is not None else None

    def normalize(self,v: np.ndarray) -> np.ndarray:
        return v / np.linalg.norm(v)

    def _screen_to_ray(self,x,y) -> Tuple[np.ndarray, np.ndarray] :
        focal_point = np.array(self._plotter.camera.focal_point)
        position = np.array(self._plotter.camera.position)
        up = np.array(self._plotter.camera.up)

        forward = self.normalize(focal_point-position) #direction camera looking
        right = self.normalize(np.cross(forward,up)) # camera's right
        true_up = self.normalize(np.cross(right,forward)) #camera's true up

        width,height = self._plotter.iren.interactor.GetSize()
        #print(f"VTK reports: {width}x{height}")
        dpr = self._plotter.interactor.devicePixelRatioF()
        px,py = x*dpr,y*dpr
        
        normdevice_x =2*(px/width)-1 
        normdevice_y=1-(2*py/height)

        #print(self._plotter.iren.interactor.GetSize(), (self._plotter.interactor.width(), self._plotter.interactor.height()),self._plotter.interactor.devicePixelRatioF())
        
        view_angle = self._plotter.camera.view_angle
        tan_fov = math.tan(math.radians(view_angle)/2)

        aspect = width/height

        direction = forward + right*(normdevice_x * tan_fov *aspect) + true_up*(normdevice_y * tan_fov)
        ray_direction = self.normalize(direction)
        ray_origin = position


        return ray_origin,ray_direction

    def bilinear_height(self,x,y):
        W,H = self._width,self._height
        gx, gy = x / self._spacing, y / self._spacing        # world coords -> fractional grid coords
        

        if W < 2 or H < 2:
            return None  # terrain too small to interpolate at all

        x0 = min(int(np.floor(gx)), W - 2)                # clamp so x0+1 always exists
        y0 = min(int(np.floor(gy)), H - 2)
        
        tx, ty = gx - x0, gy - y0                # fractional position *within* that cell, both in [0,1)
        h00, h10 = self._elev[y0][x0],   self._elev[y0][x0+1]     # 4 corner heights of the cell
        h01, h11 = self._elev[y0+1][x0], self._elev[y0+1][x0+1]
        h0 = h00*(1-tx) + h10*tx     # interpolate along the top edge
        h1 = h01*(1-tx) + h11*tx     # interpolate along the bottom edge
        return h0*(1-ty) + h1*ty     # interpolate between those two results

    def ray_aabb(self,origin, direction, box_min, box_max):
        t_enter, t_exit = 0.0, float('inf')
        for axis in range(3):
            if direction[axis] == 0:
                if origin[axis] < box_min[axis] or origin[axis] > box_max[axis]:
                    return None                       # parallel to this axis, outside the box — can never hit
                continue                              # parallel but inside — this axis imposes no limit
            t1 = (box_min[axis] - origin[axis]) / direction[axis]
            t2 = (box_max[axis] - origin[axis]) / direction[axis]
            if t1 > t2:
                t1, t2 = t2, t1                       # keep t1 as the "entering" value
            t_enter = max(t_enter, t1)
            t_exit  = min(t_exit,  t2)
            if t_enter > t_exit:
                return None                           # this axis rules out any overlap — box missed
        return t_enter, t_exit

    def _intersect_heightfield(self,origin,direction):
        result = self.ray_aabb(origin, direction, self._box_min, self._box_max)
        if result is None:
            return None                     # can't possibly hit — skip the DDA loop entirely
        t_enter, t_exit = result
        
        t = max(t_enter, 0)                 # don't bother marching before the box even starts
        t_max = t_exit 
        entry_point = origin + direction * t

        W,H = self._terrain.getDimensions()
        gx,gy = entry_point[0]/self._spacing,entry_point[1]/self._spacing
        cell_x,cell_y = int(np.floor(gx)),int(np.floor(gy))

        step_x =1 if direction[0] >0 else -1
        step_y = 1 if direction[1] >0 else -1

        boundary_x = cell_x + (1 if step_x > 0 else 0)
        boundary_y = cell_y + (1 if step_y > 0 else 0)
        

        t_max_x =np.inf if direction[0]==0 else t+(boundary_x - gx) / direction[0] * self._spacing
        t_max_y=np.inf if direction[1]==0 else t+(boundary_y - gy) / direction[1] * self._spacing
        t_delta_x = np.inf if direction[0]==0 else self._spacing/ np.abs(direction[0])
        t_delta_y = np.inf if direction[1]==0 else self._spacing/ np.abs(direction[1])

           
        
        while t < t_max:
            if  (0 <= cell_y < H-1) and  (0 <= cell_x < W-1):
                t_next = min(t_max_x, t_max_y)

                p_enter = origin + direction*t
                p_exit = origin + direction*t_next

                h_enter = self.bilinear_height(p_enter[0],p_enter[1])
                h_exit = self.bilinear_height(p_exit[0],p_exit[1])

                diff_enter = p_enter[2] -h_enter
                diff_exit = p_exit[2] -h_exit

                if diff_enter>0 and diff_exit <=0:
                    #ray crossed surface somewhere inside this cell
                    lo,hi =t,t_next
                    i=0
                    while i<20 :
                        i+=1
                        mid = (lo + hi)/2
                        p = origin + direction*mid
                        h = self.bilinear_height(p[0],p[1])
                        if (p[2] - h)>0:
                            lo=mid
                        else:
                            hi =mid
                        hit_t = (lo+hi)/2
                    return origin + direction*hit_t

            if t_max_x < t_max_y:
                t = t_max_x
                t_max_x += t_delta_x
                cell_x += step_x
            else:
                t = t_max_y
                t_max_y += t_delta_y
                cell_y += step_y

        return None            


