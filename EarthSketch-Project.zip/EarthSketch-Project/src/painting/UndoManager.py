"""
Tracks undo/redo history for brush strokes (soil painting and depth sculpting),
using whole-region numpy snapshots.
"""

from dataclasses import dataclass, field
from typing import Dict, List, Optional
import numpy as np
from ..core.Terrain import Terrain
from ..rendering.Renderer import Renderer


@dataclass
class PaintAction:
    """
    One undoable unit of work — a full brush stroke, mouse-down to mouse-up.
    Bounds grow as the stroke is painted; before/after are numpy snapshots
    of that final bounding box, filled in once at end_stroke.
    """
    row_min: Optional[int] = None
    row_max: Optional[int] = None
    col_min: Optional[int] = None
    col_max: Optional[int] = None
    before: Dict[str, np.ndarray] = field(default_factory=dict)
    after: Dict[str, np.ndarray] = field(default_factory=dict)

    def expand_bounds(self, row_min: int, row_max: int, col_min: int, col_max: int) -> None:
        if self.row_min is None:
            self.row_min, self.row_max = row_min, row_max
            self.col_min, self.col_max = col_min, col_max
        else:
            self.row_min = min(self.row_min, row_min)
            self.row_max = max(self.row_max, row_max)
            self.col_min = min(self.col_min, col_min)
            self.col_max = max(self.col_max, col_max)

    def is_empty(self) -> bool:
        return self.row_min is None


class UndoManager:
    """
    Bounded undo/redo history of PaintActions.
    """

    def __init__(self, terrain: Terrain, renderer: Renderer, max_history: int = 100):
        self.terrain = terrain
        self.renderer = renderer
        self.max_history = max_history
        self._undo_stack: List[PaintAction] = []
        self._redo_stack: List[PaintAction] = []

    def push(self, action: PaintAction) -> None:
        if action.is_empty():
            return
        self._undo_stack.append(action)
        if len(self._undo_stack) > self.max_history:
            self._undo_stack.pop(0)
        self._redo_stack.clear()

    def undo(self) -> bool:
        if not self._undo_stack:
            return False
        action = self._undo_stack.pop()
        self._apply(action, action.before)
        self._redo_stack.append(action)
        return True

    def redo(self) -> bool:
        if not self._redo_stack:
            return False
        action = self._redo_stack.pop()
        self._apply(action, action.after)
        self._undo_stack.append(action)
        return True

    def can_undo(self) -> bool:
        return len(self._undo_stack) > 0

    def can_redo(self) -> bool:
        return len(self._redo_stack) > 0

    def clear(self) -> None:
        self._undo_stack.clear()
        self._redo_stack.clear()

    def _apply(self, action: PaintAction, data: Dict[str, np.ndarray]) -> None:
        r0, r1 = action.row_min, action.row_max
        c0, c1 = action.col_min, action.col_max

        self.terrain.sand[r0:r1, c0:c1] = data['sand']
        self.terrain.silt[r0:r1, c0:c1] = data['silt']
        self.terrain.clay[r0:r1, c0:c1] = data['clay']
        self.terrain.depth[r0:r1, c0:c1] = data['depth']
        self.terrain.is_soil_modified = True

        # Renderer only visualizes soil today; harmless no-op recolor for depth-only undos.
        # TODO(depth visualization): trigger a depth-visual refresh here too, once it exists.
        self.renderer.update_colours_region(r0, r1, c0, c1)