"""
Coordinates brush interactif with the terrain and renderer. This is MainWindow's only entry point for painting.
"""

from typing import Optional, Tuple, List
from .Brush import Brush,  PAINT_MODES, DEPTH_EDIT_MODES,EFFECT_MODES
from ..rendering.Renderer import Renderer
from .RayCast import RayCast, RaycastHit
from ..core.Terrain import Terrain
from .UndoManager import PaintAction, UndoManager



class BrushManager:
    """
    Manages the currently active brush and connects painting operations
    to the terrain renderer. Undo/redo is captured by snapshotting the
    full soil/depth grids once at stroke-start and diffing the final
    touched region against that snapshot at stroke-end.
    """

    def __init__(self, terrain: Terrain, renderer: Renderer, undo_manager: UndoManager) -> None:
        self.terrain = terrain
        self.renderer = renderer
        self.brush = Brush(terrain = terrain)
        self.undo_manager = undo_manager
        self._last_cell: Optional[Tuple[int, int]] = None
        self._current_action: Optional[PaintAction] = None
        self._stroke_before: Optional[dict] = None

    def begin_stroke(self) -> None:
        """Call on mouse press, before the first paint() of a stroke."""
        self._current_action = PaintAction()
        self._stroke_before = {
            'sand': self.terrain.sand.copy(),
            'silt': self.terrain.silt.copy(),
            'clay': self.terrain.clay.copy(),
            'depth': self.terrain.depth.copy(),
        }

    def set_custom_soil(self,sand:float,silt:float,clay:float)->None:
        self.brush.set_custom_soil(sand,silt,clay)

    def paint(self, hit: RaycastHit) -> None:
        cell = (hit.cell_row, hit.cell_col)
        if cell == self._last_cell:
            return

        cells = [cell] if self._last_cell is None else self._interpolate(self._last_cell, cell)

        batch_row_min = batch_row_max = batch_col_min = batch_col_max = None
        for row, col in cells:
            step_hit = RaycastHit(world_position=hit.world_position, cell_row=row, cell_col=col)
            row_min, row_max, col_min, col_max = self.brush.paint(step_hit)
            if row_min is None:
                continue

            if self._current_action is not None:
                self._current_action.expand_bounds(row_min, row_max, col_min, col_max)

            if batch_row_min is None:
                batch_row_min, batch_row_max = row_min, row_max
                batch_col_min, batch_col_max = col_min, col_max
            else:
                batch_row_min = min(batch_row_min, row_min)
                batch_row_max = max(batch_row_max, row_max)
                batch_col_min = min(batch_col_min, col_min)
                batch_col_max = max(batch_col_max, col_max)

        if batch_row_min is not None:
            self.renderer.update_colours_region(batch_row_min, batch_row_max, batch_col_min, batch_col_max)

        self._last_cell = cell

    def _interpolate(self, start: Tuple[int, int], end: Tuple[int, int]) -> List[Tuple[int, int]]:
        """Bresenham line between two grid cells, so a fast drag doesn't skip cells."""
        r1, c1 = start
        r2, c2 = end
        delta_r = abs(r2 - r1)
        delta_c = abs(c2 - c1)
        err = delta_r - delta_c
        sr = 1 if r1 < r2 else -1
        sc = 1 if c1 < c2 else -1
        r, c = r1, c1
        cells = []
        while True:
            cells.append((r, c))
            if r == r2 and c == c2:
                break
            e2 = 2 * err
            if e2 > -delta_c:
                err -= delta_c
                r += sr
            if e2 < delta_r:
                err += delta_r
                c += sc
        return cells

    def end_stroke(self) -> None:
        """Call on mouse release: snapshot the final region and commit undo history."""
        self._last_cell = None

        if (self._current_action is not None
                and not self._current_action.is_empty()
                and self.undo_manager is not None):

            r0 = max(0, self._current_action.row_min)
            r1 = min(self._current_action.row_max, self.terrain.height)
            c0 = max(0, self._current_action.col_min)
            c1 = min(self._current_action.col_max, self.terrain.width)

            self._current_action.row_min, self._current_action.row_max = r0, r1
            self._current_action.col_min, self._current_action.col_max = c0, c1

            self._current_action.before = {
                key: grid[r0:r1, c0:c1].copy() for key, grid in self._stroke_before.items()
            }
            self._current_action.after = {
                'sand': self.terrain.sand[r0:r1, c0:c1].copy(),
                'silt': self.terrain.silt[r0:r1, c0:c1].copy(),
                'clay': self.terrain.clay[r0:r1, c0:c1].copy(),
                'depth': self.terrain.depth[r0:r1, c0:c1].copy(),
            }
            self.undo_manager.push(self._current_action)

        self._current_action = None
        self._stroke_before = None

    # Soil brush passthroughs
    def set_size(self, size: int):
        self.brush.set_size(size)
    
    def get_size(self) -> int:
        return self.brush.size

    # Paint-mode / depth passthroughs
    def set_paint_mode(self, mode: PAINT_MODES):
        self.brush.set_paint_mode(mode)

    def get_paint_mode(self) -> PAINT_MODES:
        return self.brush.paintMode

    def set_effect(self, mode: EFFECT_MODES):
        self.brush.set_effect_type(mode)

    def set_depth_mode(self,mode:DEPTH_EDIT_MODES):
        self.brush.set_depth_mode(mode)

    def get_depth_mode(self) -> DEPTH_EDIT_MODES:
        return self.brush.depthEditMode

    def set_depth_value(self, value: float):
        self.brush.set_depth_value(value)

    def set_depth_delta(self, delta: float):
        self.brush.set_depth_delta(delta)
