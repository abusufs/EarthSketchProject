"""
Unit tests for Renderer.py - 3D mesh, colour mapping and bed-of-nails depth view
Run with: python -m unittest tests.TestRenderer -v
      or: python tests/TestRenderer.py
"""
import sys
from pathlib import Path
from unittest.mock import MagicMock

# 1. Add project root to sys.path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# 2. Mock pyvistaqt before importing Renderer or BrushManager
sys.modules["pyvistaqt"] = MagicMock()

import unittest
import numpy as np
from src.core.Terrain import Terrain
from src.rendering.Renderer import Renderer


def pin_lengths(renderer):
    """Vertical length of every nail (each nail is a 2-point line)."""
    pts = renderer.nails_mesh.points.reshape(-1, 2, 3)
    return pts[:, 0, 2] - pts[:, 1, 2]


class TestRenderer(unittest.TestCase):
    """Test suite for the Renderer class."""

    def setUp(self):
        """Create a test terrain and renderer before each test."""
        self.width = 5
        self.height = 5
        self.spacing = 1.0
        self.latitude = 0.0
        self.elevations = [
            [1.0, 2.0, 3.0, 4.0, 5.0],
            [2.0, 3.0, 4.0, 5.0, 6.0],
            [3.0, 4.0, 5.0, 6.0, 7.0],
            [4.0, 5.0, 6.0, 7.0, 8.0],
            [5.0, 6.0, 7.0, 8.0, 9.0],
        ]
        self.terrain = Terrain(self.width, self.height, self.spacing,
                               self.latitude, self.elevations)
        self.renderer = Renderer()
        # The mocked QtInteractor returns one shared object, so give every test
        # its own fresh plot mock to keep call counts independent between tests.
        self.renderer.plot = MagicMock()

    def _large_terrain(self, width=100, height=60, seed=1):
        rng = np.random.default_rng(seed)
        return Terrain(width, height, 1.0, 0.0, rng.random((height, width)) * 100)

    # ------------------------------------------------------------------
    # Initial state
    # ------------------------------------------------------------------

    def test_initial_state(self):
        r = Renderer()
        self.assertIsNone(r.terrain)
        self.assertIsNone(r.mesh)
        self.assertIsNone(r.base_mesh)
        self.assertIsNone(r.nails_mesh)
        self.assertEqual(r.colour_mode, "soil")
        self.assertTrue(r.show_depth)
        self.assertEqual(r.depth_exaggeration, 0.15)

    def test_add_to_plot_without_terrain_does_nothing(self):
        self.renderer._add_to_plot()
        self.renderer.plot.add_mesh.assert_not_called()

    # ------------------------------------------------------------------
    # Mesh generation
    # ------------------------------------------------------------------

    def test_set_terrain_builds_mesh(self):
        self.renderer.set_terrain(self.terrain)
        self.assertIsNotNone(self.renderer.mesh)
        self.assertIsNotNone(self.renderer.base_mesh)
        self.assertIsNotNone(self.renderer.nails_mesh)

    def test_build_mesh_creates_correct_number_of_points(self):
        self.renderer.set_terrain(self.terrain)
        self.assertEqual(self.renderer.mesh.n_points, self.width * self.height)

    def test_build_mesh_creates_correct_number_of_cells(self):
        self.renderer.set_terrain(self.terrain)
        self.assertEqual(self.renderer.mesh.n_cells,
                         (self.width - 1) * (self.height - 1))

    def test_build_mesh_with_terrain_spacing(self):
        terrain_spacing = Terrain(3, 3, 2.0, 0.0, np.ones((3, 3)))
        self.renderer.set_terrain(terrain_spacing)
        points = self.renderer.mesh.points
        np.testing.assert_allclose(np.unique(points[:, 0]), [0.0, 2.0, 4.0])
        np.testing.assert_allclose(np.unique(points[:, 1]), [0.0, 2.0, 4.0])

    def test_build_mesh_z_matches_elevation(self):
        self.renderer.set_terrain(self.terrain)
        z = self.renderer.mesh.points[:, 2].reshape(5, 5)
        np.testing.assert_allclose(z, self.elevations)

    def test_build_mesh_non_square_non_power_of_two(self):
        """Client requirement: no square / power-of-two assumption."""
        rng = np.random.default_rng(3)
        terrain = Terrain(13, 7, 1.0, 0.0, rng.random((7, 13)))
        self.renderer.set_terrain(terrain)
        self.assertEqual(self.renderer.mesh.n_points, 13 * 7)
        self.assertEqual(self.renderer.mesh.n_cells, 12 * 6)

    def test_set_terrain_adds_actors_to_plot(self):
        self.renderer.set_terrain(self.terrain)
        self.assertIsNotNone(self.renderer.actor)
        self.assertIsNotNone(self.renderer.base_actor)
        self.assertIsNotNone(self.renderer.nails_actor)
        self.renderer.plot.render.assert_called()

    # ------------------------------------------------------------------
    # Base block
    # ------------------------------------------------------------------

    def test_build_base_creates_base_mesh(self):
        self.renderer.set_terrain(self.terrain)
        self.assertGreater(self.renderer.base_mesh.n_points, 0)
        self.assertGreater(self.renderer.base_mesh.n_cells, 0)

    def test_build_base_extrudes_downward(self):
        self.renderer.set_terrain(self.terrain)
        min_terrain_z = float(np.min(self.elevations))
        self.assertLess(self.renderer.base_mesh.bounds[4], min_terrain_z)

    def test_build_base_spans_terrain_footprint(self):
        self.renderer.set_terrain(self.terrain)
        b = self.renderer.base_mesh.bounds
        self.assertAlmostEqual(b[0], 0.0)
        self.assertAlmostEqual(b[1], 4.0)
        self.assertAlmostEqual(b[2], 0.0)
        self.assertAlmostEqual(b[3], 4.0)

    def test_build_base_is_five_faces_of_a_skirt(self):
        """4 walls of (n-1) quads each + 1 bottom quad."""
        self.renderer.set_terrain(self.terrain)
        self.assertEqual(self.renderer.base_mesh.n_cells, 4 * 4 + 1)

    # ------------------------------------------------------------------
    # Colour mapping (soil mode)
    # ------------------------------------------------------------------

    def test_compute_face_colours_returns_correct_shape(self):
        self.renderer.set_terrain(self.terrain)
        colours = self.renderer._compute_face_colours()
        self.assertEqual(colours.shape, (16, 3))

    def test_compute_face_colours_values_in_range(self):
        self.renderer.set_terrain(self.terrain)
        colours = self.renderer._compute_face_colours()
        self.assertGreaterEqual(colours.min(), 0.0)
        self.assertLessEqual(colours.max(), 1.0)

    def test_compute_face_colours_reflects_soil_data(self):
        self.terrain.set_soil_texture(0, 0, 100.0, 0.0, 0.0)
        self.renderer.set_terrain(self.terrain)
        colours = self.renderer._compute_face_colours()
        np.testing.assert_allclose(colours[0], [1.0, 0.0, 0.0], atol=1e-5)

    def test_compute_face_colours_without_terrain_is_empty(self):
        self.assertEqual(self.renderer._compute_face_colours().shape, (0, 3))

    def test_update_colours_updates_mesh_data(self):
        self.renderer.set_terrain(self.terrain)
        self.terrain.set_soil_texture(0, 0, 0.0, 100.0, 0.0)
        self.renderer.update_colours()
        np.testing.assert_allclose(self.renderer.mesh.cell_data['RGB'][0],
                                   [0.0, 1.0, 0.0], atol=1e-5)

    def test_update_colours_preserves_other_cell_data(self):
        self.renderer.set_terrain(self.terrain)
        before = np.array(self.renderer.mesh.cell_data['RGB'][5])
        self.terrain.set_soil_texture(0, 0, 0.0, 100.0, 0.0)
        self.renderer.update_colours()
        np.testing.assert_allclose(self.renderer.mesh.cell_data['RGB'][5], before)

    def test_update_colours_without_terrain_is_safe(self):
        self.renderer.update_colours()  # must not raise

    # ------------------------------------------------------------------
    # Partial (region) colour updates - used by real-time painting
    # ------------------------------------------------------------------

    def test_update_colours_region_only_changes_region(self):
        self.renderer.set_terrain(self.terrain)
        before = np.array(self.renderer.mesh.cell_data['RGB'])
        self.terrain.set_soil_texture(1, 1, 100.0, 0.0, 0.0)
        self.renderer.update_colours_region(1, 2, 1, 2)
        after = np.array(self.renderer.mesh.cell_data['RGB'])
        changed = np.where(~np.isclose(before, after).all(axis=1))[0]
        self.assertEqual(list(changed), [1 * 4 + 1])  # row 1, col 1 of 4x4 cells
        np.testing.assert_allclose(after[5], [1.0, 0.0, 0.0], atol=1e-5)

    def test_update_colours_region_clamps_to_bounds(self):
        self.renderer.set_terrain(self.terrain)
        self.renderer.update_colours_region(-5, 99, -5, 99)  # must not raise

    def test_update_colours_region_empty_region_is_noop(self):
        self.renderer.set_terrain(self.terrain)
        before = np.array(self.renderer.mesh.cell_data['RGB'])
        self.renderer.update_colours_region(3, 3, 0, 4)
        np.testing.assert_allclose(self.renderer.mesh.cell_data['RGB'], before)

    def test_update_colours_region_without_terrain_is_safe(self):
        self.renderer.update_colours_region(0, 1, 0, 1)

    def test_update_colours_region_matches_full_update(self):
        self.renderer.set_terrain(self.terrain)
        self.terrain.set_soil_texture(2, 2, 10.0, 10.0, 80.0)
        self.renderer.update_colours_region(0, 4, 0, 4)
        partial = np.array(self.renderer.mesh.cell_data['RGB'])
        full = self.renderer._compute_face_colours()
        np.testing.assert_allclose(partial, full, atol=1e-5)

    # ------------------------------------------------------------------
    # Colour mode + depth ramp
    # ------------------------------------------------------------------

    def test_set_colour_mode_invalid_raises(self):
        with self.assertRaises(ValueError):
            self.renderer.set_colour_mode("elevation")

    def test_set_colour_mode_depth_changes_colours(self):
        self.terrain.set_soil_depth(0, 0, 3.0)
        self.renderer.set_terrain(self.terrain)
        soil_colours = np.array(self.renderer.mesh.cell_data['RGB'])
        self.renderer.set_colour_mode("depth")
        self.assertEqual(self.renderer.colour_mode, "depth")
        self.assertFalse(np.allclose(soil_colours, self.renderer.mesh.cell_data['RGB']))

    def test_set_colour_mode_same_mode_is_noop(self):
        self.renderer.set_terrain(self.terrain)
        self.renderer.plot.render.reset_mock()
        self.renderer.set_colour_mode("soil")
        self.renderer.plot.render.assert_not_called()

    def test_depth_ramp_colours_endpoints(self):
        r = self.renderer
        ramp = r._depth_ramp_colours(np.array([[0.0, 1.0]], dtype=np.float32), 0.0, 1.0)
        np.testing.assert_allclose(ramp[0, 0], [0.05, 0.35, 0.45], atol=1e-5)  # shallow
        np.testing.assert_allclose(ramp[0, 1], [0.35, 0.95, 1.00], atol=1e-5)  # deep

    def test_depth_ramp_colours_zero_span_does_not_divide_by_zero(self):
        ramp = self.renderer._depth_ramp_colours(np.ones((2, 2), dtype=np.float32), 1.0, 1.0)
        self.assertTrue(np.isfinite(ramp).all())

    # ------------------------------------------------------------------
    # Depth range
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # Bed-of-nails depth visualisation
    # ------------------------------------------------------------------

    def test_nails_built_for_small_terrain(self):
        """5x5 terrain -> stride 1 -> one nail per cell, 2 points per nail."""
        self.renderer.set_terrain(self.terrain)
        self.assertEqual(self.renderer.nails_mesh.n_points, 25 * 2)

    def test_nail_count_is_capped_on_large_terrain(self):
        """Pins are strided so a big terrain is not a solid wall of nails."""
        terrain = self._large_terrain(100, 60)   # stride = 100 // 45 = 2
        self.renderer.set_terrain(terrain)
        expected_pins = len(range(0, 60, 2)) * len(range(0, 100, 2))
        self.assertEqual(self.renderer.nails_mesh.n_points, expected_pins * 2)

    def test_nail_count_bounded_for_1024_terrain(self):
        terrain = Terrain(1024, 1024, 1.0, 0.0, np.zeros((1024, 1024)))
        self.renderer.set_terrain(terrain)
        pins = self.renderer.nails_mesh.n_points // 2
        self.assertLessEqual(pins, 50 * 50)

    def test_nails_hang_downward_from_surface(self):
        terrain = self._large_terrain(50, 50)
        self.renderer.set_terrain(terrain)
        self.assertTrue((pin_lengths(self.renderer) >= 0).all())
        tops = self.renderer.nails_mesh.points.reshape(-1, 2, 3)[:, 0, 2]
        self.assertLessEqual(tops.max(), float(np.max(terrain.elevations)) + 1e-3)

    def test_nail_length_is_proportional_to_soil_depth(self):
        """Core requirement: pin length encodes soil depth."""
        terrain = self._large_terrain(50, 50)
        terrain.depth = np.random.default_rng(5).random((50, 50)) + 0.1
        self.renderer.set_terrain(terrain)
        stride = max(1, 50 // self.renderer.nail_density)
        depths = np.asarray(terrain.depth)[::stride, ::stride].reshape(-1)
        lengths = pin_lengths(self.renderer)
        ratio = lengths / depths
        np.testing.assert_allclose(ratio, ratio[0], rtol=1e-3)

    def test_deepest_soil_gets_a_deeper_nail_than_shallow_soil(self):
        terrain = Terrain(5, 5, 1.0, 0.0, np.linspace(0, 100, 25).reshape(5, 5))
        terrain.depth = np.full((5, 5), 0.5)
        terrain.depth[4, 4] = 2.0
        self.renderer.set_terrain(terrain)
        lengths = pin_lengths(self.renderer).reshape(5, 5)
        self.assertGreater(lengths[4, 4], lengths[0, 0])
        self.assertAlmostEqual(lengths[4, 4] / lengths[0, 0], 4.0, places=2)

    def test_deepest_nail_is_exaggeration_fraction_of_relief(self):
        terrain = self._large_terrain(45, 45)
        relief = float(np.ptp(terrain.elevations))
        self.renderer.set_terrain(terrain)   # stride 1: every cell has a nail
        self.assertAlmostEqual(pin_lengths(self.renderer).max(),
                               0.15 * relief, delta=0.01 * relief)

    def test_nails_carry_depth_scalar(self):
        self.renderer.set_terrain(self.terrain)
        self.assertIn("depth", self.renderer.nails_mesh.point_data)

    def test_nails_with_flat_terrain_do_not_crash(self):
        flat = Terrain(5, 5, 1.0, 0.0, np.full((5, 5), 10.0))
        self.renderer.set_terrain(flat)   # relief == 0 -> zero-length pins, no error
        self.assertIsNotNone(self.renderer.nails_mesh)

    def test_set_depth_exaggeration_lengthens_nails(self):
        terrain = self._large_terrain(45, 45)
        self.renderer.set_terrain(terrain)
        before = pin_lengths(self.renderer).max()
        self.renderer.set_depth_exaggeration(0.30)
        after = pin_lengths(self.renderer).max()
        self.assertAlmostEqual(after / before, 2.0, places=2)

    def test_set_depth_exaggeration_stores_value(self):
        self.renderer.set_terrain(self.terrain)
        self.renderer.set_depth_exaggeration(0.4)
        self.assertEqual(self.renderer.depth_exaggeration, 0.4)

    def test_set_depth_exaggeration_has_minimum(self):
        self.renderer.set_terrain(self.terrain)
        self.renderer.set_depth_exaggeration(0.0)
        self.assertEqual(self.renderer.depth_exaggeration, 0.01)
        self.renderer.set_depth_exaggeration(-3)
        self.assertEqual(self.renderer.depth_exaggeration, 0.01)

    def test_set_depth_exaggeration_never_changes_true_depths(self):
        """Exaggeration is a drawing scale only; the data must be untouched."""
        self.renderer.set_terrain(self.terrain)
        before = np.array(self.terrain.depth)
        self.renderer.set_depth_exaggeration(0.6)
        np.testing.assert_array_equal(self.terrain.depth, before)

    def test_set_depth_exaggeration_deepens_base_block(self):
        terrain = self._large_terrain(45, 45)
        self.renderer.set_terrain(terrain)
        before = self.renderer.base_mesh.bounds[4]
        self.renderer.set_depth_exaggeration(0.6)
        self.assertLess(self.renderer.base_mesh.bounds[4], before)

    def test_set_depth_exaggeration_without_terrain_is_safe(self):
        self.renderer.set_depth_exaggeration(0.3)

    # ------------------------------------------------------------------
    # Depth-view checkbox (show / hide bed of nails)
    # ------------------------------------------------------------------

    def _mesh_calls(self):
        """Return {kwargs} of every add_mesh call made since last reset."""
        return [c.kwargs for c in self.renderer.plot.add_mesh.call_args_list]

    def test_depth_view_on_adds_translucent_surface_and_nails(self):
        self.renderer.set_terrain(self.terrain)
        calls = self._mesh_calls()
        self.assertEqual(len(calls), 3)               # nails + surface + base
        self.assertEqual(calls[0].get("scalars"), "depth")
        self.assertEqual(calls[1]["opacity"], 0.45)   # see-through surface
        self.assertEqual(calls[2]["opacity"], 0.30)   # see-through base

    def test_set_depth_visible_false_hides_nails_and_makes_surface_opaque(self):
        self.renderer.set_terrain(self.terrain)
        self.renderer.plot.add_mesh.reset_mock()
        self.renderer.set_depth_visible(False)
        calls = self._mesh_calls()
        self.assertEqual(len(calls), 2)               # surface + base only
        self.assertEqual(calls[0]["opacity"], 1.0)
        self.assertEqual(calls[1]["opacity"], 1.0)
        self.assertIsNone(self.renderer.nails_actor)
        self.assertFalse(self.renderer.show_depth)

    def test_set_depth_visible_true_restores_nails(self):
        self.renderer.set_terrain(self.terrain)
        self.renderer.set_depth_visible(False)
        self.renderer.plot.add_mesh.reset_mock()
        self.renderer.set_depth_visible(True)
        self.assertEqual(len(self._mesh_calls()), 3)
        self.assertIsNotNone(self.renderer.nails_actor)
        self.assertTrue(self.renderer.show_depth)

    def test_set_depth_visible_removes_old_actors_first(self):
        self.renderer.set_terrain(self.terrain)
        self.renderer.plot.remove_actor.reset_mock()
        self.renderer.set_depth_visible(False)
        self.assertEqual(self.renderer.plot.remove_actor.call_count, 3)

    def test_set_depth_visible_coerces_to_bool(self):
        self.renderer.set_depth_visible(0)
        self.assertIs(self.renderer.show_depth, False)
        self.renderer.set_depth_visible(1)
        self.assertIs(self.renderer.show_depth, True)

    def test_set_depth_visible_without_terrain_is_safe(self):
        self.renderer.set_depth_visible(False)
        self.renderer.plot.add_mesh.assert_not_called()

    def test_scalar_bar_reports_true_depth_in_metres(self):
        self.renderer.set_terrain(self.terrain)
        nails_call = self._mesh_calls()[0]
        self.assertEqual(nails_call["scalar_bar_args"]["title"], "Soil depth (m)")

    def test_scalar_bar_removed_when_nails_hidden(self):
        self.renderer.set_terrain(self.terrain)
        self.renderer.set_depth_visible(False)
        self.renderer.plot.remove_scalar_bar.assert_called_with("Soil depth (m)")

    # ------------------------------------------------------------------
    # Elevation updates / clearing
    # ------------------------------------------------------------------

    def test_update_elevations_rebuilds_mesh(self):
        self.renderer.set_terrain(self.terrain)
        old_mesh = self.renderer.mesh
        self.terrain.elevations[2][2] = 50.0
        self.renderer.update_elevations()
        self.assertIsNot(self.renderer.mesh, old_mesh)
        self.assertEqual(self.renderer.mesh.points[12, 2], 50.0)

    def test_update_elevations_rebuilds_nails(self):
        self.renderer.set_terrain(self.terrain)
        old_nails = self.renderer.nails_mesh
        self.renderer.update_elevations()
        self.assertIsNot(self.renderer.nails_mesh, old_nails)

    def test_update_elevations_removes_old_actor(self):
        self.renderer.set_terrain(self.terrain)
        self.renderer.plot.remove_actor.reset_mock()
        self.renderer.update_elevations()
        self.assertGreaterEqual(self.renderer.plot.remove_actor.call_count, 3)

    def test_update_elevations_without_terrain_is_safe(self):
        self.renderer.update_elevations()

    def test_clear_terrain_removes_terrain_data(self):
        self.renderer.set_terrain(self.terrain)
        self.renderer.clear_terrain()
        self.assertIsNone(self.renderer.terrain)
        self.assertIsNone(self.renderer.mesh)
        self.assertIsNone(self.renderer.base_mesh)
        self.assertIsNone(self.renderer.nails_mesh)
        self.assertIsNone(self.renderer.actor)
        self.assertIsNone(self.renderer.base_actor)
        self.assertIsNone(self.renderer.nails_actor)

    def test_clear_terrain_without_terrain_is_safe(self):
        self.renderer.clear_terrain()

    def test_set_terrain_twice_replaces_previous_terrain(self):
        self.renderer.set_terrain(self.terrain)
        bigger = Terrain(8, 6, 1.0, 0.0, np.random.default_rng(0).random((6, 8)))
        self.renderer.set_terrain(bigger)
        self.assertEqual(self.renderer.mesh.n_points, 8 * 6)

    # ------------------------------------------------------------------
    # Performance
    # ------------------------------------------------------------------

    def test_colour_region_update_within_realtime_budget(self):
        """Brush requirement: a stroke's colour update must finish in < 1/20 s."""
        import time
        terrain = self._large_terrain(512, 512)
        self.renderer.set_terrain(terrain)
        start = time.perf_counter()
        for _ in range(10):
            self.renderer.update_colours_region(200, 250, 200, 250)
        per_update = (time.perf_counter() - start) / 10
        self.assertLess(per_update, 0.05, f"{per_update * 1000:.1f} ms per update")


if __name__ == '__main__':
    unittest.main()
