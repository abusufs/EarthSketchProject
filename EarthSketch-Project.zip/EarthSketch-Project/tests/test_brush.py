import unittest
import sys
from pathlib import Path

project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from src.painting.Brush import Brush
from src.painting.RayCast import RaycastHit
from src.core.Terrain import Terrain

class TestBrush(unittest.TestCase):
    def setUp(self):
        self.terrain = Terrain(width=5, height=5, spacing=1.0, latitude=0.0, elevations=[[0.0]*5 for _ in range(5)])
        self.brush = Brush(terrain=self.terrain, size=1, soilType="sand")

    def test_initialization_defaults(self):
        self.assertEqual(self.brush.size, 1)
        self.assertEqual(self.brush.soilType, "sand")

    def test_set_size_valid_and_invalid(self):
        self.brush.set_size(3)
        self.assertEqual(self.brush.size, 3)

        with self.assertRaises(ValueError):
            self.brush.set_size(0)

    def test_set_soil_type_valid_and_invalid(self):
        self.brush.set_soil_type("clay")
        self.assertEqual(self.brush.soilType, "clay")

        with self.assertRaises(ValueError):
            self.brush.set_soil_type("gravel")  # Invalid soil type

    def test_paint_single_cell(self):
        hit = RaycastHit(world_position=(2.0, 2.0, 0.0), cell_row=2, cell_col=2)
        self.brush.set_soil_type("clay")
        self.brush.paint(hit)

        sand, silt, clay = self.terrain.get_soil_texture(2, 2)
        self.assertEqual((sand, silt, clay), (0.0, 0.0, 100.0))

    def test_paint_radius_brush(self):
        # Size 3 has a radius of 1 (covers a 3x3 grid centered at row 2, col 2)
        self.brush.set_size(3)
        self.brush.set_soil_type("silt")
        hit = RaycastHit(world_position=(2.0, 2.0, 0.0), cell_row=2, cell_col=2)
        self.brush.paint(hit)

        for r in range(1, 4):
            for c in range(1, 4):
                _, silt, _ = self.terrain.get_soil_texture(r, c)
                self.assertEqual(silt, 100.0)

    def test_paint_boundary_protection(self):
        # Center at border corner (0,0); bounds-checking should skip invalid cells silently
        self.brush.set_size(3)
        hit = RaycastHit(world_position=(0.0, 0.0, 0.0), cell_row=0, cell_col=0)
        
        try:
            self.brush.paint(hit)
        except IndexError:
            self.fail("paint() raised IndexError on boundary cells!")

    def test_paint_sequential_texture_overwrites(self):
        """Verifies that painting multiple soil types in sequence correctly updates cell values."""
        hit = RaycastHit(world_position=(2.0, 2.0, 0.0), cell_row=2, cell_col=2)
        
        # First Pass: Paint Sand
        self.brush.set_soil_type("sand")
        self.brush.paint(hit)
        
        # Second Pass: Paint Silt over the exact same cell
        self.brush.set_soil_type("silt")
        self.brush.paint(hit)
        
        # Use the exact same assertion logic as test_paint_single_cell:
        # e.g., self.assertEqual(self.terrain.silt_matrix[2, 2], 100.0) 
        # OR self.assertEqual(self.terrain.get_soil_percentages(2, 2)["silt"], 100.0)

if __name__ == '__main__':
    unittest.main()