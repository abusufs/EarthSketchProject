"""
Unit tests for Terrain.py - Core terrain data model
Run with: python -m unittest tests.TestTerrain -v
      or: python tests/TestTerrain.py
"""
import sys
import io
from pathlib import Path
from unittest.mock import MagicMock, patch

# 1. Add project root to sys.path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# 2. Mock pyvistaqt before importing Renderer or BrushManager
sys.modules["pyvistaqt"] = MagicMock()

import unittest
import numpy as np
from src.core.Terrain import Terrain
from src.core.Exceptions import TerrainValidationError


def make_ramp(width, height, step=1.0):
    """Elevation grid that rises by `step` per column."""
    return np.tile(np.arange(width, dtype=np.float64) * step, (height, 1))


class TestTerrain(unittest.TestCase):
    """Test suite for the Terrain class."""

    def setUp(self):
        """Create a test terrain before each test."""
        self.width = 5
        self.height = 5
        self.spacing = 1.0
        self.latitude = 0.0
        self.elevations = [
            [1.0, 2.0, 3.0, 4.0, 5.0],
            [2.0, 3.0, 4.0, 5.0, 6.0],
            [3.0, 4.0, 5.0, 6.0, 7.0],
            [4.0, 5.0, 6.0, 7.0, 8.0],
            [5.0, 6.0, 7.0, 8.0, 9.0],
        ]
        self.terrain = Terrain(self.width, self.height, self.spacing,
                               self.latitude, self.elevations)

    # ------------------------------------------------------------------
    # Construction / validation
    # ------------------------------------------------------------------

    def test_terrain_initialization(self):
        """Constructor stores all header properties."""
        self.assertEqual(self.terrain.width, 5)
        self.assertEqual(self.terrain.height, 5)
        self.assertEqual(self.terrain.spacing, 1.0)
        self.assertEqual(self.terrain.latitude, 0.0)
        self.assertEqual(self.terrain.elevations, self.elevations)
        self.assertFalse(self.terrain.is_soil_modified)

    def test_terrain_non_square_dimensions(self):
        """Terrains do not have to be square (client requirement)."""
        t = Terrain(7, 4, 1.0, 0.0, make_ramp(7, 4))
        self.assertEqual(t.getDimensions(), (7, 4))
        self.assertEqual(np.asarray(t.sand).shape, (4, 7))
        self.assertEqual(np.asarray(t.depth).shape, (4, 7))

    def test_terrain_non_power_of_two_dimensions(self):
        """Dimensions do not have to be a power of two (client requirement)."""
        t = Terrain(13, 11, 2.5, -33.9, make_ramp(13, 11))
        self.assertEqual(t.getDimensions(), (13, 11))
        self.assertEqual(np.asarray(t.silt).shape, (11, 13))

    def test_terrain_initialization_invalid_width(self):
        with self.assertRaises(ValueError):
            Terrain(0, 5, 1.0, 0.0, self.elevations)

    def test_terrain_initialization_invalid_height(self):
        with self.assertRaises(ValueError):
            Terrain(5, -1, 1.0, 0.0, self.elevations)

    def test_terrain_initialization_invalid_spacing(self):
        with self.assertRaises(ValueError):
            Terrain(5, 5, 0.0, 0.0, self.elevations)
        with self.assertRaises(ValueError):
            Terrain(5, 5, -1.0, 0.0, self.elevations)

    def test_terrain_initialization_wrong_row_count(self):
        with self.assertRaises(ValueError):
            Terrain(5, 4, 1.0, 0.0, self.elevations)  # 5 rows given, 4 expected

    def test_terrain_initialization_wrong_column_count(self):
        bad = [row[:4] for row in self.elevations]
        with self.assertRaises(ValueError):
            Terrain(5, 5, 1.0, 0.0, bad)

    def test_terrain_initialization_non_numeric_list(self):
        bad = [row[:] for row in self.elevations]
        bad[2][2] = "high"
        with self.assertRaises(TypeError):
            Terrain(5, 5, 1.0, 0.0, bad)

    def test_terrain_numpy_fast_path_valid(self):
        """The numpy fast path (used by the loader) builds a valid terrain."""
        t = Terrain(6, 3, 1.0, 0.0, make_ramp(6, 3))
        self.assertEqual(t.width, 6)
        self.assertEqual(t.height, 3)

    def test_terrain_numpy_wrong_shape(self):
        with self.assertRaises(ValueError):
            Terrain(5, 5, 1.0, 0.0, np.zeros((4, 5)))

    def test_terrain_numpy_1d_rejected(self):
        with self.assertRaises(ValueError):
            Terrain(5, 5, 1.0, 0.0, np.zeros(25))

    def test_terrain_numpy_nan_rejected(self):
        grid = np.zeros((5, 5))
        grid[1, 1] = np.nan
        with self.assertRaises(ValueError):
            Terrain(5, 5, 1.0, 0.0, grid)

    def test_terrain_numpy_inf_rejected(self):
        grid = np.zeros((5, 5))
        grid[0, 0] = np.inf
        with self.assertRaises(ValueError):
            Terrain(5, 5, 1.0, 0.0, grid)

    def test_terrain_numpy_non_numeric_dtype_rejected(self):
        with self.assertRaises(TypeError):
            Terrain(2, 2, 1.0, 0.0, np.array([["a", "b"], ["c", "d"]]))

    # ------------------------------------------------------------------
    # Default soil initialisation (gradient / elevation aware)
    # ------------------------------------------------------------------

    def test_default_soil_grids_match_terrain_shape(self):
        for grid in (self.terrain.sand, self.terrain.silt,
                     self.terrain.clay, self.terrain.depth):
            self.assertEqual(np.asarray(grid).shape, (5, 5))

    def test_default_soil_percentages_sum_to_100(self):
        total = self.terrain.sand + self.terrain.silt + self.terrain.clay
        np.testing.assert_allclose(total, 100.0, atol=1e-6)

    def test_default_soil_is_valid(self):
        self.assertTrue(self.terrain.validate_soil_data())

    def test_default_soil_flat_terrain_uses_base_mix(self):
        """With no slope the soil falls back to the 50/30/20 base mix."""
        t = Terrain(6, 6, 1.0, 0.0, np.full((6, 6), 10.0))
        np.testing.assert_allclose(t.sand, 50.0)
        np.testing.assert_allclose(t.silt, 30.0)
        np.testing.assert_allclose(t.clay, 20.0)

    def test_default_soil_is_not_constant_on_varied_terrain(self):
        """Client requirement: defaults must not be constant values."""
        grid = make_ramp(10, 10)
        grid[:, 5:] = np.arange(5, dtype=np.float64) * 20 + 100  # steep right half
        grid[:, :5] = 0.0                                          # flat left half
        t = Terrain(10, 10, 1.0, 0.0, grid)
        self.assertGreater(np.ptp(t.sand), 1.0)
        self.assertGreater(np.ptp(t.depth), 0.1)

    def test_default_sand_decreases_on_steep_ground(self):
        grid = np.zeros((10, 10))
        grid[:, 5:] = (np.arange(5) + 1) * 20.0   # left flat, right steep
        t = Terrain(10, 10, 1.0, 0.0, grid)
        self.assertGreater(t.sand[5, 0], t.sand[5, 8])

    def test_default_silt_and_clay_increase_on_steep_ground(self):
        grid = np.zeros((10, 10))
        grid[:, 5:] = (np.arange(5) + 1) * 20.0
        t = Terrain(10, 10, 1.0, 0.0, grid)
        self.assertLess(t.silt[5, 0], t.silt[5, 8])
        self.assertLess(t.clay[5, 0], t.clay[5, 8])

    def test_default_depth_thinner_on_steep_ground(self):
        grid = np.zeros((10, 10))
        grid[:, 5:] = (np.arange(5) + 1) * 20.0
        t = Terrain(10, 10, 1.0, 0.0, grid)
        self.assertGreater(t.depth[5, 0], t.depth[5, 8])

    def test_default_depth_deeper_in_hollow(self):
        """Local topographic lows accumulate material -> deeper soil."""
        grid = np.full((9, 9), 10.0)
        grid[4, 4] = 5.0
        t = Terrain(9, 9, 1.0, 0.0, grid)
        self.assertGreater(t.depth[4, 4], t.depth[0, 0])

    def test_default_depth_never_zero(self):
        grid = make_ramp(10, 10, step=500.0)
        t = Terrain(10, 10, 1.0, 0.0, grid)
        self.assertGreaterEqual(np.asarray(t.depth).min(), 0.05)

    def test_compute_slope_of_flat_terrain_is_zero(self):
        t = Terrain(5, 5, 1.0, 0.0, np.full((5, 5), 3.0))
        np.testing.assert_allclose(t._compute_slope(), 0.0)

    def test_compute_slope_of_uniform_ramp(self):
        """A ramp rising 1 per cell with spacing 2 has slope 0.5."""
        t = Terrain(6, 6, 2.0, 0.0, make_ramp(6, 6, 1.0))
        np.testing.assert_allclose(t._compute_slope(), 0.5)

    # ------------------------------------------------------------------
    # Getters
    # ------------------------------------------------------------------

    def test_get_elevation_valid(self):
        self.assertEqual(self.terrain.getElevation(0, 0), 1.0)
        self.assertEqual(self.terrain.getElevation(4, 4), 9.0)

    def test_get_elevation_out_of_bounds(self):
        with self.assertRaises(IndexError):
            self.terrain.getElevation(5, 0)
        with self.assertRaises(IndexError):
            self.terrain.getElevation(0, -1)

    def test_basic_getters(self):
        self.assertEqual(self.terrain.getDimensions(), (5, 5))
        self.assertEqual(self.terrain.getSpacing(), 1.0)
        self.assertEqual(self.terrain.getLatitude(), 0.0)
        self.assertEqual(self.terrain.getElevations(), self.elevations)

    def test_get_soil_texture_valid(self):
        sand, silt, clay = self.terrain.get_soil_texture(2, 2)
        self.assertAlmostEqual(sand + silt + clay, 100.0, places=6)

    def test_get_soil_texture_out_of_bounds(self):
        with self.assertRaises(IndexError):
            self.terrain.get_soil_texture(10, 10)

    def test_get_soil_depth_valid(self):
        self.assertGreater(self.terrain.get_soil_depth(2, 2), 0.0)

    def test_get_all_soil_data_valid(self):
        sand, silt, clay, depth = self.terrain.get_all_soil_data(1, 1)
        self.assertAlmostEqual(sand + silt + clay, 100.0, places=6)
        self.assertGreater(depth, 0.0)

    # ------------------------------------------------------------------
    # Setters
    # ------------------------------------------------------------------

    def test_set_elevation_valid(self):
        self.terrain.set_elevation(1, 1, 99.5)
        self.assertEqual(self.terrain.getElevation(1, 1), 99.5)

    def test_set_elevation_invalid_type(self):
        with self.assertRaises(TypeError):
            self.terrain.set_elevation(1, 1, "tall")

    def test_set_elevation_out_of_bounds(self):
        with self.assertRaises(IndexError):
            self.terrain.set_elevation(9, 9, 1.0)

    def test_set_soil_texture_valid(self):
        self.terrain.set_soil_texture(2, 2, 60.0, 30.0, 10.0)
        sand, silt, clay = self.terrain.get_soil_texture(2, 2)
        self.assertAlmostEqual(sand, 60.0)
        self.assertAlmostEqual(silt, 30.0)
        self.assertAlmostEqual(clay, 10.0)
        self.assertTrue(self.terrain.is_soil_modified)

    def test_set_soil_texture_only_changes_target_cell(self):
        before = self.terrain.get_soil_texture(0, 0)
        self.terrain.set_soil_texture(2, 2, 100.0, 0.0, 0.0)
        self.assertEqual(self.terrain.get_soil_texture(0, 0), before)

    def test_set_soil_texture_invalid_sum(self):
        with self.assertRaises(TerrainValidationError):
            self.terrain.set_soil_texture(2, 2, 50.0, 50.0, 50.0)

    def test_set_soil_texture_negative_rejected(self):
        with self.assertRaises(TerrainValidationError):
            self.terrain.set_soil_texture(2, 2, -10.0, 60.0, 50.0)

    def test_set_soil_texture_over_100_rejected(self):
        with self.assertRaises(TerrainValidationError):
            self.terrain.set_soil_texture(2, 2, 120.0, 0.0, 0.0)

    def test_set_soil_texture_non_numeric_rejected(self):
        with self.assertRaises(TerrainValidationError):
            self.terrain.set_soil_texture(2, 2, "a", 50.0, 50.0)

    def test_set_soil_texture_out_of_bounds(self):
        with self.assertRaises(IndexError):
            self.terrain.set_soil_texture(5, 5, 50.0, 30.0, 20.0)

    def test_set_soil_depth_valid(self):
        self.terrain.set_soil_depth(3, 3, 2.5)
        self.assertEqual(self.terrain.get_soil_depth(3, 3), 2.5)
        self.assertTrue(self.terrain.is_soil_modified)

    def test_set_soil_depth_zero_accepted(self):
        self.terrain.set_soil_depth(3, 3, 0)
        self.assertEqual(self.terrain.get_soil_depth(3, 3), 0)

    def test_set_soil_depth_negative(self):
        with self.assertRaises(TerrainValidationError):
            self.terrain.set_soil_depth(3, 3, -0.1)

    def test_set_soil_depth_non_numeric(self):
        with self.assertRaises(TerrainValidationError):
            self.terrain.set_soil_depth(3, 3, "deep")

    def test_set_all_soil_data(self):
        self.terrain.set_all_soil_data(0, 0, 20.0, 30.0, 50.0, 1.75)
        self.assertEqual(self.terrain.get_all_soil_data(0, 0)[3], 1.75)
        self.assertAlmostEqual(self.terrain.get_soil_texture(0, 0)[2], 50.0)

    # ------------------------------------------------------------------
    # NumPy helpers
    # ------------------------------------------------------------------

    def test_get_elevation_grid_numpy(self):
        grid = self.terrain.get_elevation_grid_numpy()
        self.assertEqual(grid.shape, (5, 5))
        self.assertEqual(grid.dtype, np.float32)
        self.assertEqual(grid[0, 0], 1.0)

    def test_get_soil_grids_numpy(self):
        sand, silt, clay, depth = self.terrain.get_soil_grids_numpy()
        for grid in (sand, silt, clay, depth):
            self.assertEqual(grid.shape, (5, 5))
            self.assertEqual(grid.dtype, np.float32)


    # ------------------------------------------------------------------
    # Classification
    # ------------------------------------------------------------------

    def _classify(self, sand, silt, clay):
        self.terrain.set_soil_texture(0, 0, sand, silt, clay)
        return self.terrain.get_soil_classification(0, 0)

    def test_classification_sand(self):
        self.assertEqual(self._classify(90.0, 5.0, 5.0), "Sand")

    def test_classification_sandy_loam(self):
        self.assertEqual(self._classify(60.0, 25.0, 15.0), "Sandy Loam")

    def test_classification_silt_loam(self):
        self.assertEqual(self._classify(10.0, 70.0, 20.0), "Silt Loam")

    def test_classification_clay(self):
        self.assertEqual(self._classify(20.0, 30.0, 50.0), "Clay")

    def test_classification_clay_loam(self):
        self.assertEqual(self._classify(30.0, 35.0, 35.0), "Clay Loam")

    def test_classification_loam(self):
        self.assertEqual(self._classify(35.0, 40.0, 25.0), "Loam")

    # ------------------------------------------------------------------
    # Validation
    # ------------------------------------------------------------------

    def test_validate_coordinates_bounds(self):
        self.terrain._validate_coordinates(0, 0)
        self.terrain._validate_coordinates(4, 4)
        with self.assertRaises(IndexError):
            self.terrain._validate_coordinates(-1, 0)
        with self.assertRaises(IndexError):
            self.terrain._validate_coordinates(0, 5)

    def test_validate_soil_data_detects_bad_sum(self):
        self.terrain.sand[0][0] = 90.0  # breaks the sum-to-100 rule
        self.assertFalse(self.terrain.validate_soil_data())

    def test_validate_soil_data_detects_out_of_range(self):
        self.terrain.sand[0][0] = 150.0
        self.assertFalse(self.terrain.validate_soil_data())

    def test_validate_soil_data_detects_negative_depth(self):
        self.terrain.depth[0][0] = -1.0
        self.assertFalse(self.terrain.validate_soil_data())

    # ------------------------------------------------------------------
    # Statistics
    # ------------------------------------------------------------------

    def test_get_elevation_stats(self):
        stats = self.terrain.get_elevation_stats()
        self.assertEqual(stats["min"], 1.0)
        self.assertEqual(stats["max"], 9.0)
        self.assertEqual(stats["mean"], 5.0)
        self.assertEqual(stats["count"], 25)

    def test_get_soil_stats(self):
        stats = self.terrain.get_soil_stats()
        self.assertEqual(set(stats), {"sand", "silt", "clay", "depth"})
        for band in stats.values():
            self.assertLessEqual(band["min"], band["mean"])
            self.assertLessEqual(band["mean"], band["max"])
        mean_total = (stats["sand"]["mean"] + stats["silt"]["mean"]
                      + stats["clay"]["mean"])
        self.assertAlmostEqual(mean_total, 100.0, places=4)

    # ------------------------------------------------------------------
    # Weighted (brush) bulk updates
    # ------------------------------------------------------------------

    def test_apply_weighted_update_full_weight(self):
        arr = np.zeros((5, 5))
        self.terrain.apply_weighted_update(arr, 1, 3, 1, 3, np.ones((2, 2)), 10.0)
        self.assertTrue((arr[1:3, 1:3] == 10.0).all())
        self.assertEqual(arr.sum(), 40.0)
        self.assertTrue(self.terrain.is_soil_modified)

    def test_apply_weighted_update_half_weight_blends(self):
        arr = np.full((5, 5), 10.0)
        self.terrain.apply_weighted_update(arr, 0, 2, 0, 2, np.full((2, 2), 0.5), 20.0)
        self.assertTrue((arr[0:2, 0:2] == 15.0).all())
        self.assertEqual(arr[4, 4], 10.0)

    def test_apply_weighted_update_clamped_at_edge(self):
        """A box hanging off the terrain edge must not raise and must clip."""
        arr = np.zeros((5, 5))
        self.terrain.apply_weighted_update(arr, -1, 2, -1, 2, np.ones((3, 3)), 1.0)
        self.assertTrue((arr[0:2, 0:2] == 1.0).all())
        self.assertEqual(arr.sum(), 4.0)

    def test_apply_weighted_update_fully_outside_does_nothing(self):
        arr = np.zeros((5, 5))
        self.terrain.apply_weighted_update(arr, 10, 12, 10, 12, np.ones((2, 2)), 1.0)
        self.assertEqual(arr.sum(), 0.0)
        self.assertFalse(self.terrain.is_soil_modified)

    def test_apply_weighed_depth_update_applies_function(self):
        arr = np.full((5, 5), 2.0)
        self.terrain.apply_weighed_depth_update(
            arr, 1, 3, 1, 3, np.ones((2, 2)), lambda region, w: region + w)
        self.assertTrue((arr[1:3, 1:3] == 3.0).all())
        self.assertEqual(arr[0, 0], 2.0)
        self.assertTrue(self.terrain.is_soil_modified)

    # ------------------------------------------------------------------
    # Output
    # ------------------------------------------------------------------

    def test_print_summary_runs(self):
        with patch("sys.stdout", new_callable=io.StringIO) as out:
            self.terrain.print_summary()
        text = out.getvalue()
        self.assertIn("Terrain Summary", text)
        self.assertIn("5 x 5", text)

    def test_to_string_row_major_three_decimals(self):
        result = self.terrain.toString([[1.0, 2.0], [3.0, 4.0]])
        self.assertEqual(result.split(), ["1.000", "2.000", "3.000", "4.000"])

    def test_to_elv_format(self):
        """Header line + one string per band (elevation, sand, clay, silt, depth)."""
        result = self.terrain.to_elv_format()
        self.assertIsInstance(result, list)
        self.assertEqual(len(result), 6)
        self.assertEqual(result[0].split(), ["5", "5", "1.0", "0.0"])
        for band in result[1:]:
            self.assertEqual(len(band.split()), 25)


if __name__ == '__main__':
    unittest.main()
