import unittest
import tempfile
import sys
from pathlib import Path
from unittest.mock import patch

# Add project root directory (EarthSketch-project) to Python's search path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))



# Use clean absolute imports (no leading dots)
from src.core.TerrainSaver import TerrainSaver, TerrainSaveError
from src.core.Terrain import Terrain

class TestTerrainSaver(unittest.TestCase):
    def setUp(self):
        self.terrain = Terrain(width=2, height=2, spacing=1.0, latitude=12.5, elevations=[[1.0, 2.0], [3.0, 4.0]])

    def test_save_all_success(self):
        with tempfile.TemporaryDirectory() as tmp_dir:
            file_path = Path(tmp_dir) / "subfolder" / "test_terrain.elv"
            TerrainSaver.save_all(self.terrain, file_path)

            self.assertTrue(file_path.exists())
            self.assertGreater(file_path.stat().st_size, 0)

            content = file_path.read_text()
            self.assertIn("2 2 1.0 12.5", content)
            self.assertIn("BAND: elevation", content)
            self.assertIn("BAND: sand", content)

    @patch.object(Terrain, 'validate_soil_data', return_value=False)
    def test_save_all_invalid_soil_data(self, mock_validate):
        with tempfile.TemporaryDirectory() as tmp_dir:
            file_path = Path(tmp_dir) / "invalid.elv"
            with self.assertRaises(TerrainSaveError):
                TerrainSaver.save_all(self.terrain, file_path)

    @patch("builtins.open", side_effect=OSError("Disk error or permission denied"))
    def test_save_all_os_error(self, mock_open):
        with tempfile.TemporaryDirectory() as tmp_dir:
            file_path = Path(tmp_dir) / "test.elv"
            with self.assertRaises(TerrainSaveError):
                TerrainSaver.save_all(self.terrain, file_path)
                
if __name__ == '__main__':
    unittest.main()