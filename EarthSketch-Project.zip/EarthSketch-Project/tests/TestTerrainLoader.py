"""
Unit tests for TerrainLoader.py - File loading functionality
Run with: python -m unittest tests.TestTerrainLoader -v
      or: python tests/TestTerrainLoader.py
"""
import sys
from pathlib import Path
from unittest.mock import MagicMock

# 1. Add project root to sys.path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# 2. Mock pyvistaqt before importing Renderer or BrushManager
sys.modules["pyvistaqt"] = MagicMock()

import unittest
import tempfile
import os
import time
import numpy as np
from src.core.Terrain import Terrain
from src.core.TerrainLoader import TerrainLoader, TerrainLoadError
from src.core.TerrainSaver import TerrainSaver


class TestTerrainLoader(unittest.TestCase):
    """Test suite for the TerrainLoader class."""

    def setUp(self):
        """Create a temporary directory and valid test file before each test."""
        self.temp_dir = tempfile.mkdtemp()
        self.valid_file = Path(self.temp_dir) / "valid.elv"

        # Create a valid 3x3 test file
        with open(self.valid_file, 'w') as f:
            f.write("3 3 1.0 0.0\n")
            f.write("1.0 2.0 3.0\n")
            f.write("4.0 5.0 6.0\n")
            f.write("7.0 8.0 9.0\n")

    def tearDown(self):
        """Clean up temporary files after each test."""
        for file in Path(self.temp_dir).glob("*"):
            file.unlink()
        os.rmdir(self.temp_dir)

    def _write(self, name, text):
        path = Path(self.temp_dir) / name
        with open(path, 'w') as f:
            f.write(text)
        return path

    # --- Valid Load Tests ---

    def test_load_valid_file(self):
        """Loading a valid .elv file returns a Terrain with correct data."""
        terrain = TerrainLoader.load(self.valid_file)

        self.assertEqual(terrain.width, 3)
        self.assertEqual(terrain.height, 3)
        self.assertEqual(terrain.spacing, 1.0)
        self.assertEqual(terrain.latitude, 0.0)

        expected_elevations = [
            [1.0, 2.0, 3.0],
            [4.0, 5.0, 6.0],
            [7.0, 8.0, 9.0],
        ]
        np.testing.assert_array_equal(terrain.elevations, expected_elevations)

    def test_load_valid_file_accepts_string_path(self):
        terrain = TerrainLoader.load(str(self.valid_file))
        self.assertIsInstance(terrain, Terrain)

    def test_load_valid_file_with_trailing_whitespace(self):
        """Extra whitespace/newlines are tolerated."""
        path = self._write("whitespace.elv",
                           "  3   3    1.0   0.0  \n"
                           "  1.0  2.0  3.0  \n"
                           "  4.0  5.0  6.0  \n"
                           "  7.0  8.0  9.0  \n\n")
        terrain = TerrainLoader.load(path)
        self.assertEqual(terrain.width, 3)
        self.assertEqual(terrain.height, 3)

    def test_load_values_split_across_arbitrary_lines(self):
        """The grid is read as a token stream, so line breaks do not matter."""
        path = self._write("oneline.elv", "3 3 1.0 0.0\n1 2 3 4 5 6 7 8 9\n")
        terrain = TerrainLoader.load(path)
        self.assertEqual(terrain.elevations[2][2], 9.0)

    def test_load_non_square_terrain(self):
        """Client requirement: terrains are not assumed to be square."""
        path = self._write("wide.elv", "4 2 1.0 0.0\n1 2 3 4\n5 6 7 8\n")
        terrain = TerrainLoader.load(path)
        self.assertEqual((terrain.width, terrain.height), (4, 2))
        self.assertEqual(np.asarray(terrain.elevations).shape, (2, 4))
        self.assertEqual(terrain.elevations[1][3], 8.0)

    def test_load_non_power_of_two_terrain(self):
        """Client requirement: dimensions are not assumed to be a power of two."""
        rows = "\n".join(" ".join(str(c + r) for c in range(7)) for r in range(5))
        path = self._write("odd.elv", "7 5 2.5 -33.9\n" + rows + "\n")
        terrain = TerrainLoader.load(path)
        self.assertEqual((terrain.width, terrain.height), (7, 5))
        self.assertEqual(terrain.spacing, 2.5)
        self.assertEqual(terrain.latitude, -33.9)

    def test_load_boundary_latitudes_accepted(self):
        for lat in ("90", "-90"):
            path = self._write("lat.elv", "2 2 1.0 " + lat + "\n1 2\n3 4\n")
            self.assertEqual(TerrainLoader.load(path).latitude, float(lat))

    def test_load_negative_elevations_accepted(self):
        path = self._write("neg.elv", "2 2 1.0 0.0\n-5 -2\n-1 3\n")
        self.assertEqual(TerrainLoader.load(path).elevations[0][0], -5.0)

    # --- Default soil initialisation (gradient / elevation aware) ---

    def test_load_legacy_file_gets_default_soil(self):
        """An elevation-only file is given valid soil data automatically."""
        terrain = TerrainLoader.load(self.valid_file)
        self.assertEqual(np.asarray(terrain.sand).shape, (3, 3))
        self.assertEqual(np.asarray(terrain.depth).shape, (3, 3))
        self.assertTrue(terrain.validate_soil_data())

    def test_load_legacy_file_default_soil_is_not_constant(self):
        """Defaults must react to terrain shape (flat vs steep), not be constants."""
        rows = []
        for r in range(10):
            vals = [0.0] * 5 + [(c + 1) * 20.0 for c in range(5)]
            rows.append(" ".join(str(v) for v in vals))
        path = self._write("varied.elv", "10 10 1.0 0.0\n" + "\n".join(rows) + "\n")
        terrain = TerrainLoader.load(path)
        self.assertGreater(np.ptp(terrain.sand), 1.0)
        self.assertGreater(np.ptp(terrain.depth), 0.1)
        # steep right side holds less sand and thinner soil than the flat left
        self.assertGreater(terrain.sand[5][0], terrain.sand[5][8])
        self.assertGreater(terrain.depth[5][0], terrain.depth[5][8])

    # --- Band-structured (saved) files ---

    def _band_file(self, bands, name="banded.elv", header="2 2 1.0 0.0"):
        text = header + "\n"
        for band_name, values in bands:
            text += "BAND: " + band_name + "\n" + values + "\n"
        return self._write(name, text)

    def test_load_band_file_full_soil(self):
        path = self._band_file([
            ("elevation", "1 2 3 4"),
            ("sand", "60 60 60 60"),
            ("silt", "30 30 30 30"),
            ("clay", "10 10 10 10"),
            ("depth", "0.5 1.0 1.5 2.0"),
        ])
        terrain = TerrainLoader.load(path)
        self.assertEqual(terrain.sand[0][0], 60.0)
        self.assertEqual(terrain.clay[1][1], 10.0)
        self.assertEqual(terrain.depth[1][1], 2.0)
        self.assertTrue(terrain.validate_soil_data())

    def test_load_band_file_elevation_only_uses_default_soil(self):
        terrain = TerrainLoader.load(self._band_file([("elevation", "1 2 3 4")]))
        self.assertTrue(terrain.validate_soil_data())

    def test_load_band_file_depth_only_keeps_default_texture(self):
        terrain = TerrainLoader.load(self._band_file([
            ("elevation", "1 2 3 4"), ("depth", "1 1 1 1")]))
        np.testing.assert_allclose(terrain.depth, 1.0)
        self.assertTrue(terrain.validate_soil_data())

    def test_load_band_names_case_insensitive(self):
        path = self._write("case.elv", "2 2 1.0 0.0\nband: ELEVATION\n1 2 3 4\n")
        self.assertEqual(TerrainLoader.load(path).elevations[1][1], 4.0)

    def test_load_band_file_missing_elevation(self):
        path = self._band_file([("sand", "1 1 1 1")])
        with self.assertRaises(TerrainLoadError) as ctx:
            TerrainLoader.load(path)
        self.assertIn("elevation", str(ctx.exception))

    def test_load_band_file_partial_soil_bands_rejected(self):
        path = self._band_file([("elevation", "1 2 3 4"), ("sand", "50 50 50 50")])
        with self.assertRaises(TerrainLoadError) as ctx:
            TerrainLoader.load(path)
        self.assertIn("sand / silt / clay", str(ctx.exception))

    def test_load_band_file_duplicate_band_rejected(self):
        path = self._band_file([("elevation", "1 2 3 4"), ("elevation", "1 2 3 4")])
        with self.assertRaises(TerrainLoadError) as ctx:
            TerrainLoader.load(path)
        self.assertIn("Duplicate", str(ctx.exception))

    def test_load_band_file_unknown_band_rejected(self):
        path = self._band_file([("elevation", "1 2 3 4"), ("moisture", "1 2 3 4")])
        with self.assertRaises(TerrainLoadError) as ctx:
            TerrainLoader.load(path)
        self.assertIn("Unknown BAND", str(ctx.exception))

    def test_load_band_file_wrong_value_count_rejected(self):
        path = self._band_file([("elevation", "1 2 3")])
        with self.assertRaises(TerrainLoadError) as ctx:
            TerrainLoader.load(path)
        self.assertIn("Expected 4", str(ctx.exception))

    def test_load_band_file_soil_not_summing_to_100_rejected(self):
        path = self._band_file([
            ("elevation", "1 2 3 4"),
            ("sand", "90 90 90 90"), ("silt", "30 30 30 30"), ("clay", "10 10 10 10"),
        ])
        with self.assertRaises(TerrainLoadError) as ctx:
            TerrainLoader.load(path)
        self.assertIn("validation", str(ctx.exception))

    def test_load_band_file_negative_depth_rejected(self):
        path = self._band_file([("elevation", "1 2 3 4"), ("depth", "1 -1 1 1")])
        with self.assertRaises(TerrainLoadError):
            TerrainLoader.load(path)

    def test_load_band_file_non_numeric_value_rejected(self):
        path = self._band_file([("elevation", "1 2 x 4")])
        with self.assertRaises(TerrainLoadError) as ctx:
            TerrainLoader.load(path)
        self.assertIn("Invalid number", str(ctx.exception))

    

    # --- Error Handling Tests ---

    def test_load_missing_file(self):
        missing_file = Path(self.temp_dir) / "missing.elv"
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(missing_file)
        self.assertIn("File not found", str(context.exception))

    def test_load_empty_file(self):
        empty_file = Path(self.temp_dir) / "empty.elv"
        empty_file.touch()
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(empty_file)
        self.assertIn("File is empty", str(context.exception))

    def test_load_directory_instead_of_file(self):
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(self.temp_dir)
        self.assertIn("directory", str(context.exception))

    def test_load_blank_header_line(self):
        path = self._write("blank_header.elv", "\n1 2 3\n")
        with self.assertRaises(TerrainLoadError):
            TerrainLoader.load(path)

    def test_load_invalid_header_missing_values(self):
        path = self._write("invalid_header.elv", "3 3 1.0\n1.0 2.0 3.0\n4.0 5.0 6.0\n")
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(path)
        self.assertIn("Invalid header", str(context.exception))

    def test_load_invalid_header_too_many_values(self):
        path = self._write("long_header.elv", "3 3 1.0 0.0 7\n1 2 3\n4 5 6\n7 8 9\n")
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(path)
        self.assertIn("Invalid header", str(context.exception))

    def test_load_invalid_header_non_numeric(self):
        path = self._write("nonnumeric.elv", "three 3 1.0 0.0\n1.0 2.0 3.0\n")
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(path)
        self.assertIn("invalid numeric", str(context.exception))

    def test_load_invalid_header_fractional_dimension(self):
        path = self._write("fraction.elv", "3.5 3 1.0 0.0\n1 2 3\n")
        with self.assertRaises(TerrainLoadError):
            TerrainLoader.load(path)

    def test_load_incorrect_data_count(self):
        path = self._write("mismatch.elv", "3 3 1.0 0.0\n1.0 2.0 3.0\n4.0 5.0 6.0\n")
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(path)
        self.assertIn("Expected 9", str(context.exception))

    def test_load_extra_data(self):
        path = self._write("extra.elv", "2 2 1.0 0.0\n1.0 2.0\n3.0 4.0\n5.0 6.0\n")
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(path)
        self.assertIn("Expected 4", str(context.exception))

    def test_load_non_numeric_elevation_reports_value(self):
        path = self._write("badval.elv", "2 2 1.0 0.0\n1.0 abc\n3.0 4.0\n")
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(path)
        self.assertIn("abc", str(context.exception))

    def test_load_nan_elevation_rejected(self):
        """'nan' parses as a float but must never reach the terrain."""
        path = self._write("nan.elv", "2 2 1.0 0.0\n1.0 nan\n3.0 4.0\n")
        with self.assertRaises(ValueError):
            TerrainLoader.load(path)

    def test_load_invalid_latitude(self):
        path = self._write("invalid_lat.elv", "3 3 1.0 100.0\n1 2 3\n4 5 6\n7 8 9\n")
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(path)
        self.assertIn("Latitude", str(context.exception))

    def test_load_negative_latitude(self):
        path = self._write("neg_lat.elv", "3 3 1.0 -100.0\n1 2 3\n4 5 6\n7 8 9\n")
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(path)
        self.assertIn("Latitude", str(context.exception))

    def test_load_negative_dimensions(self):
        path = self._write("neg_dim.elv", "-3 3 1.0 0.0\n1 2 3\n4 5 6\n7 8 9\n")
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(path)
        self.assertIn("positive", str(context.exception))

    def test_load_zero_dimensions(self):
        path = self._write("zero_dim.elv", "0 3 1.0 0.0\n")
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(path)
        self.assertIn("positive", str(context.exception))

    def test_load_zero_spacing(self):
        path = self._write("zero_spacing.elv", "3 3 0.0 0.0\n1 2 3\n4 5 6\n7 8 9\n")
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(path)
        self.assertIn("positive", str(context.exception))

    def test_load_negative_spacing(self):
        path = self._write("neg_spacing.elv", "3 3 -1.0 0.0\n1 2 3\n4 5 6\n7 8 9\n")
        with self.assertRaises(TerrainLoadError):
            TerrainLoader.load(path)

    def test_load_invalid_extension(self):
        """A wrong extension only prints a warning; valid content still loads."""
        txt_file = self._write("test.txt", "3 3 1.0 0.0\n1 2 3\n4 5 6\n7 8 9\n")
        terrain = TerrainLoader.load(txt_file)
        self.assertIsInstance(terrain, Terrain)

    def test_load_non_utf8_encoding(self):
        """Undecodable bytes raise a TerrainLoadError rather than crashing."""
        path = Path(self.temp_dir) / "binary.elv"
        with open(path, 'wb') as f:
            f.write(b"3 3 1.0 0.0\n\xff\xfe\xfa\xfb\n")
        with self.assertRaises(TerrainLoadError) as context:
            TerrainLoader.load(path)
        self.assertIn("encoding", str(context.exception))

    # --- Security / robustness Tests ---

    def test_load_path_traversal(self):
        """Path traversal to a non-existent target is handled safely."""
        malicious_path = Path(self.temp_dir) / "../etc/passwd"
        with self.assertRaises(TerrainLoadError):
            TerrainLoader.load(malicious_path)

    def test_load_path_traversal_relative_to_real_file_still_validated(self):
        """A '..' path that resolves to a real non-.elv file is still parsed
        strictly and rejected if the content is not a valid terrain."""
        target = self._write("secret.txt", "not a terrain file\n")
        sneaky = Path(self.temp_dir) / "sub" / ".." / target.name
        with self.assertRaises(TerrainLoadError):
            TerrainLoader.load(sneaky)

    def test_load_huge_declared_dimensions_with_little_data(self):
        """A header claiming a giant grid must fail cleanly, not allocate it."""
        path = self._write("huge.elv", "100000 100000 1.0 0.0\n1 2 3\n")
        with self.assertRaises(TerrainLoadError):
            TerrainLoader.load(path)

    def test_load_large_file(self):
        """A 100x100 file loads correctly."""
        rows = "\n".join(" ".join(str((c + r) % 10) for c in range(100))
                         for r in range(100))
        path = self._write("large.elv", "100 100 1.0 0.0\n" + rows + "\n")
        terrain = TerrainLoader.load(path)
        self.assertEqual(terrain.width, 100)
        self.assertEqual(terrain.height, 100)
        self.assertEqual(terrain.spacing, 1.0)

    # --- Performance Tests ---

    def test_load_1000x1000_file_is_fast(self):
        """Backlog DoD: a 1000x1000 terrain loads in under 2 seconds."""
        rng = np.random.default_rng(0)
        grid = rng.random((1000, 1000)) * 100
        path = Path(self.temp_dir) / "big.elv"
        with open(path, 'w') as f:
            f.write("1000 1000 1.0 0.0\n")
            np.savetxt(f, grid, fmt="%.2f")

        start = time.perf_counter()
        terrain = TerrainLoader.load(path)
        elapsed = time.perf_counter() - start

        self.assertEqual(np.asarray(terrain.elevations).shape, (1000, 1000))
        self.assertLess(elapsed, 2.0, f"Load took {elapsed:.2f}s (limit 2s)")

    # --- Sample data shipped with the project ---

    def test_load_shipped_sample_data(self):
        sample = project_root / "data" / "D1-256" / "D1-256.elv"
        if not sample.exists():
            self.skipTest("sample data not present")
        terrain = TerrainLoader.load(sample)
        self.assertEqual((terrain.width, terrain.height), (256, 256))
        self.assertTrue(terrain.validate_soil_data())


if __name__ == '__main__':
    unittest.main()
