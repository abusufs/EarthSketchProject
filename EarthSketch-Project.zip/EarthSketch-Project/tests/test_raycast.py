import unittest
import sys
from pathlib import Path
from unittest.mock import MagicMock

project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

from src.painting.RayCast import RayCast, RaycastHit
from src.core.Terrain import Terrain

class TestRayCast(unittest.TestCase):
    def setUp(self):
        self.mock_plotter = MagicMock()
        self.mock_mesh = MagicMock()
        self.terrain = Terrain(width=5, height=5, spacing=1.0, latitude=0.0, elevations=[[0.0]*5 for _ in range(5)])
        
        self.raycast = RayCast(
            plotter=self.mock_plotter,
            terrain_mesh=self.mock_mesh,
            cell_spacing=1.0,
            terrain=self.terrain,
            grid_origin=(0.0, 0.0)
        )

    def test_world_to_hit_valid_coords(self):
        hit = self.raycast._world_to_hit((2.1, 3.1, 0.5))
        self.assertIsNotNone(hit)
        self.assertEqual(hit.cell_col, 2)
        self.assertEqual(hit.cell_row, 3)
        self.assertEqual(hit.world_position, (2.1, 3.1, 0.5))

    def test_world_to_hit_out_of_bounds(self):
        # Coordinates outside grid dimensions (5x5)
        hit_out = self.raycast._world_to_hit((-1.0, 2.0, 0.0))
        self.assertIsNone(hit_out)

        hit_out_max = self.raycast._world_to_hit((10.0, 2.0, 0.0))
        self.assertIsNone(hit_out_max)

    def test_pick_at_screen_miss(self):
        # Setup mock interactor size
        self.mock_plotter.iren.interactor.GetSize.return_value = (800, 600)
        # Setup picker to return no actor (missed click)
        self.mock_plotter.picker.GetActor.return_value = None

        hit = self.raycast.pick_at_screen(100, 100)
        self.assertIsNone(hit)

    def test_pick_at_screen_hit(self):
        self.mock_plotter.iren.interactor.GetSize.return_value = (800, 600)
        self.mock_plotter.picker.GetActor.return_value = MagicMock()
        self.mock_plotter.picker.GetPickPosition.return_value = (1.0, 2.0, 0.0)

        hit = self.raycast.pick_at_screen(100, 100)
        self.assertIsNotNone(hit)
        self.assertEqual(hit.cell_col, 1)
        self.assertEqual(hit.cell_row, 2)

    def test_pick_at_ray(self):
        self.mock_mesh.ray_trace.return_value = ([(1.0, 1.0, 0.0)], None)
        hit = self.raycast.pick_at_ray((1, 1, 10), (0, 0, -1))
        self.assertIsNotNone(hit)
        self.assertEqual(hit.cell_col, 1)
        self.assertEqual(hit.cell_row, 1)

        # Test ray trace miss
        self.mock_mesh.ray_trace.return_value = ([], None)
        self.assertIsNone(self.raycast.pick_at_ray((0, 0, 0), (0, 0, 1)))

    def test_world_to_hit_with_origin_offset(self):
        """Validates spatial calculation when terrain origin is offset (e.g., origin=(10.0, 20.0))."""
        raycast_offset = RayCast(
            plotter=MagicMock(),
            terrain_mesh=MagicMock(),
            cell_spacing=1.0,
            terrain=self.terrain,
            grid_origin=(10.0, 20.0)
        )
        
        # Target point (12.0, 23.0, 0.0) -> col = (12-10)/1 = 2, row = (23-20)/1 = 3
        hit = raycast_offset._world_to_hit((12.0, 23.0, 0.0))
        
        self.assertIsNotNone(hit)
        self.assertEqual(hit.cell_col, 2)
        self.assertEqual(hit.cell_row, 3)
        
if __name__ == '__main__':
    unittest.main()