"""
Unit tests for Camera.py - 3D camera controls
Run with: python -m unittest tests.test_Camera -v
"""
import sys
from pathlib import Path
from unittest.mock import MagicMock

# 1. Add project root to sys.path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# 2. Mock pyvistaqt before importing Renderer or BrushManager
sys.modules["pyvistaqt"] = MagicMock()

import unittest
import numpy as np
from unittest.mock import Mock, MagicMock, patch
from src.core.Terrain import Terrain
from src.rendering.Camera import Camera


class TestCamera(unittest.TestCase):
    """Test suite for the Camera class."""

    def setUp(self):
        """Create a mock plotter and camera before each test."""
        # Create a mock plotter
        self.mock_plotter = Mock()
        self.mock_camera = Mock()
        self.mock_camera.position = (10.0, 10.0, 10.0)
        self.mock_camera.focal_point = (0.0, 0.0, 0.0)
        self.mock_camera.up = (0.0, 0.0, 1.0)
        self.mock_plotter.camera = self.mock_camera

        # Create the camera with the mock
        self.camera = Camera(self.mock_plotter)

        # Create a test terrain
        self.terrain = Terrain(10, 10, 1.0, 0.0, [
            [1.0 for _ in range(10)] for _ in range(10)
        ])

    def test_camera_initialization(self):
        """Test that the camera initializes correctly."""
        self.assertEqual(self.camera.plotter, self.mock_plotter)
        self.assertEqual(self.camera._camera, self.mock_camera)

    def test_apply_and_render_called(self):
        """Test that _apply_and_render updates the plotter."""
        self.camera._apply_and_render()
        self.mock_plotter.render.assert_called_once()

    def test_focus_on_terrain_sets_correct_position(self):
        """Test that focus_on_terrain positions the camera correctly."""
        self.camera.focus_on_terrain(self.terrain)

        # The camera should be at a position away from the terrain
        position = np.array(self.mock_camera.position)
        focal_point = np.array(self.mock_camera.focal_point)

        # Camera should not be at the focal point
        self.assertFalse(np.allclose(position, focal_point))

        # Z-axis should be up
        self.assertEqual(self.mock_camera.up, (0.0, 0.0, 1.0))

        # Should have rendered
        self.mock_plotter.render.assert_called()

    def test_focus_on_terrain_calculates_center_correctly(self):
        """Test that focus_on_terrain calculates the correct center."""
        # Create a terrain with known dimensions
        terrain = Terrain(4, 4, 2.0, 0.0, [
            [0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0],
            [0.0, 0.0, 0.0, 0.0],
        ])
        self.camera.focus_on_terrain(terrain)

        focal_point = np.array(self.mock_camera.focal_point)
        # Center should be at (4.0, 4.0, 0.0) - physical center of 4x4 grid with 2m spacing
        self.assertAlmostEqual(focal_point[0], 4.0)
        self.assertAlmostEqual(focal_point[1], 4.0)
        self.assertAlmostEqual(focal_point[2], 0.0)

    def test_orbit_rotates_camera(self):
        """Test that orbit rotates the camera around the focal point."""
        initial_position = np.array(self.mock_camera.position)
        initial_focal = np.array(self.mock_camera.focal_point)

        self.camera.orbit(45.0, 0.0)

        new_position = np.array(self.mock_camera.position)
        new_focal = np.array(self.mock_camera.focal_point)

        # Focal point should stay the same
        self.assertTrue(np.allclose(initial_focal, new_focal))

        # Position should change
        self.assertFalse(np.allclose(initial_position, new_position))

        # Distance from focal point should remain constant
        initial_distance = np.linalg.norm(initial_position - initial_focal)
        new_distance = np.linalg.norm(new_position - new_focal)
        self.assertAlmostEqual(initial_distance, new_distance, places=5)

        self.mock_plotter.render.assert_called()

    def test_orbit_clamps_elevation(self):
        """Test that orbit clamps elevation to prevent flipping."""
        self.camera.orbit(0.0, 100.0)  # Try to go past vertical

        position = np.array(self.mock_camera.position)
        focal_point = np.array(self.mock_camera.focal_point)

        # Elevation should be clamped to ~90 degrees
        vector = position - focal_point
        # Z component should be close to the radius (pointing almost straight up/down)
        radius = np.linalg.norm(vector)
        # At max elevation, z/radius should be close to 1
        self.assertAlmostEqual(abs(vector[2] / radius), 1.0, places=2)

    def test_zoom_moves_camera_closer(self):
        """Test that zoom moves the camera closer to the focal point."""
        initial_position = np.array(self.mock_camera.position)
        focal_point = np.array(self.mock_camera.focal_point)
        initial_distance = np.linalg.norm(initial_position - focal_point)

        self.camera.zoom(0.5)  # Zoom in

        new_position = np.array(self.mock_camera.position)
        new_distance = np.linalg.norm(new_position - focal_point)

        self.assertLess(new_distance, initial_distance)
        self.mock_plotter.render.assert_called()

    def test_zoom_moves_camera_farther(self):
        """Test that zoom moves the camera farther from the focal point."""
        initial_position = np.array(self.mock_camera.position)
        focal_point = np.array(self.mock_camera.focal_point)
        initial_distance = np.linalg.norm(initial_position - focal_point)

        self.camera.zoom(-0.5)  # Zoom out

        new_position = np.array(self.mock_camera.position)
        new_distance = np.linalg.norm(new_position - focal_point)

        self.assertGreater(new_distance, initial_distance)
        self.mock_plotter.render.assert_called()

    def test_zoom_clamps_minimum_distance(self):
        """Test that zoom prevents going through the focal point."""
        # Try to zoom in too much
        for _ in range(20):
            self.camera.zoom(1.0)

        position = np.array(self.mock_camera.position)
        focal_point = np.array(self.mock_camera.focal_point)

        # Distance should not go below 1.0
        distance = np.linalg.norm(position - focal_point)
        self.assertGreaterEqual(distance, 1.0)

    def test_pan_moves_camera_and_focal_point(self):
        """Test that pan moves both the camera and focal point."""
        initial_position = np.array(self.mock_camera.position)
        initial_focal = np.array(self.mock_camera.focal_point)

        self.camera.pan(10.0, 10.0)

        new_position = np.array(self.mock_camera.position)
        new_focal = np.array(self.mock_camera.focal_point)

        # Both should move
        self.assertFalse(np.allclose(initial_position, new_position))
        self.assertFalse(np.allclose(initial_focal, new_focal))

        # The relative vector between them should stay the same
        initial_vector = initial_position - initial_focal
        new_vector = new_position - new_focal
        self.assertTrue(np.allclose(initial_vector, new_vector))

        self.mock_plotter.render.assert_called()


    def test_reset_sets_default_position(self):
        """Test that reset sets the camera to a default position."""
        self.camera.reset()

        position = np.array(self.mock_camera.position)
        focal_point = np.array(self.mock_camera.focal_point)

        # Should be at default distance from focal point
        distance = np.linalg.norm(position - focal_point)
        self.assertAlmostEqual(distance, 150.0, places=5)

        # Z should be up
        self.assertEqual(self.mock_camera.up, (0.0, 0.0, 1.0))

        self.mock_plotter.render.assert_called()

    def test_reset_with_no_focal_point(self):
        """Test that reset works when focal point is None."""
        self.mock_camera.focal_point = None
        self.camera.reset()  # Should not crash

        position = np.array(self.mock_camera.position)
        # Should be at origin
        self.assertAlmostEqual(np.linalg.norm(position), 150.0, places=5)

    def test_get_view_matrix(self):
        """Test that get_view_matrix returns the camera's view matrix."""
        mock_matrix = np.eye(4)
        self.mock_camera.view_matrix = mock_matrix
        result = self.camera.get_view_matrix()
        self.assertTrue(np.allclose(result, mock_matrix))

    def test_get_projection_matrix(self):
        """Test that get_projection_matrix returns the camera's projection matrix."""
        mock_matrix = np.eye(4)
        self.mock_camera.projection_matrix = mock_matrix
        result = self.camera.get_projection_matrix()
        self.assertTrue(np.allclose(result, mock_matrix))


if __name__ == '__main__':
    unittest.main()