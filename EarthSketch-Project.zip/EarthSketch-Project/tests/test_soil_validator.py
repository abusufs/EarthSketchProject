import unittest

from src.core.SoilValidator import SoilValidator
from src.core.Exceptions import TerrainValidationError


class TestSoilValidator(unittest.TestCase):

    # Soil percentage tests

    def test_valid_soil_percentages(self):
        """Valid percentages that sum to 100 should not raise an exception."""
        SoilValidator.validate_soil_percentages(
            sand=50.0,
            silt=30.0,
            clay=20.0
        )

    def test_percentages_sum_to_100(self):
        """Different valid combinations that sum to 100 should pass."""
        SoilValidator.validate_soil_percentages(
            sand=100.0,
            silt=0.0,
            clay=0.0
        )

        SoilValidator.validate_soil_percentages(
            sand=0.0,
            silt=100.0,
            clay=0.0
        )

        SoilValidator.validate_soil_percentages(
            sand=0.0,
            silt=0.0,
            clay=100.0
        )

    def test_percentage_below_zero(self):
        """A negative soil percentage should raise an error."""
        with self.assertRaises(TerrainValidationError):
            SoilValidator.validate_soil_percentages(
                sand=-1.0,
                silt=51.0,
                clay=50.0
            )

    def test_percentage_above_100(self):
        """A soil percentage above 100 should raise an error."""
        with self.assertRaises(TerrainValidationError):
            SoilValidator.validate_soil_percentages(
                sand=101.0,
                silt=0.0,
                clay=0.0
            )

    def test_percentages_do_not_sum_to_100(self):
        """Soil percentages that don't sum to 100 should raise an error."""
        with self.assertRaises(TerrainValidationError):
            SoilValidator.validate_soil_percentages(
                sand=50.0,
                silt=20.0,
                clay=20.0
            )

    def test_percentage_values_must_be_numeric(self):
        """Non-numeric soil percentages should raise an error."""
        with self.assertRaises(TerrainValidationError):
            SoilValidator.validate_soil_percentages(
                sand="50",
                silt=30.0,
                clay=20.0
            )

    # Soil depth tests

    def test_valid_soil_depth(self):
        """A positive soil depth should pass."""
        SoilValidator.validate_soil_depth(1.0)

    def test_zero_soil_depth(self):
        """Zero is a valid soil depth."""
        SoilValidator.validate_soil_depth(0.0)

    def test_negative_soil_depth(self):
        """Negative soil depth should raise an error."""
        with self.assertRaises(TerrainValidationError):
            SoilValidator.validate_soil_depth(-1.0)

    def test_soil_depth_must_be_numeric(self):
        """Non-numeric soil depth should raise an error."""
        with self.assertRaises(TerrainValidationError):
            SoilValidator.validate_soil_depth("1.0")


if __name__ == "__main__":
    unittest.main()