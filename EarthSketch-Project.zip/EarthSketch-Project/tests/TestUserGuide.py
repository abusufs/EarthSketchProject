"""
Unit tests for UserGuide.py - in-app user guide dialog
Run with: python -m unittest tests.TestUserGuide -v
      or: python tests/TestUserGuide.py
Runs headless (Qt "offscreen" platform), so no window is shown.
"""
import os
import sys
from pathlib import Path
from unittest.mock import MagicMock

# 1. Add project root to sys.path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# 2. Mock pyvistaqt before importing Renderer or BrushManager
sys.modules["pyvistaqt"] = MagicMock()

# 3. Run Qt without a display (must be set before QApplication is created)
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")

import unittest
from PySide6.QtWidgets import QApplication
from src.ui.UserGuide import UserGuideDialog, GUIDE_TOPICS

_app = QApplication.instance() or QApplication(sys.argv)


def topic_html(title):
    return dict(GUIDE_TOPICS)[title]


class TestGuideTopicsData(unittest.TestCase):
    """The GUIDE_TOPICS content itself (no widgets needed)."""

    def test_topics_is_non_empty_list_of_pairs(self):
        self.assertIsInstance(GUIDE_TOPICS, list)
        self.assertGreater(len(GUIDE_TOPICS), 0)
        for entry in GUIDE_TOPICS:
            self.assertEqual(len(entry), 2)
            self.assertIsInstance(entry[0], str)
            self.assertIsInstance(entry[1], str)

    def test_titles_are_unique_and_non_empty(self):
        titles = [t for t, _ in GUIDE_TOPICS]
        self.assertTrue(all(t.strip() for t in titles))
        self.assertEqual(len(titles), len(set(titles)))

    def test_bodies_are_non_empty(self):
        for title, body in GUIDE_TOPICS:
            self.assertTrue(body.strip(), f"Topic '{title}' has an empty body")

    def test_every_body_has_a_heading(self):
        for title, body in GUIDE_TOPICS:
            self.assertIn("<h2>", body, f"Topic '{title}' has no heading")

    def test_html_tags_are_balanced(self):
        for title, body in GUIDE_TOPICS:
            for tag in ("h2", "p", "ul", "ol", "li", "table", "tr", "td", "b", "code"):
                self.assertEqual(body.count(f"<{tag}>") + body.count(f"<{tag} "),
                                 body.count(f"</{tag}>"),
                                 f"Unbalanced <{tag}> in topic '{title}'")

    def test_getting_started_topic_is_first(self):
        self.assertEqual(GUIDE_TOPICS[0][0], "Getting started")

    # --- Backlog DoD: documentation covers loading/saving, camera, brush ---

    def test_covers_loading_and_saving(self):
        html = topic_html("Loading and saving")
        for word in ("Load Terrain", "Save Terrain", "BAND:"):
            self.assertIn(word, html)

    def test_loading_topic_states_no_square_or_power_of_two_assumption(self):
        html = topic_html("Loading and saving").lower()
        self.assertIn("square", html)
        self.assertIn("powers of two", html)

    def test_loading_topic_explains_error_handling(self):
        self.assertIn("malformed", topic_html("Loading and saving"))

    def test_covers_camera_controls(self):
        html = topic_html("Moving the camera").lower()
        self.assertIn("orbit", html)
        self.assertIn("zoom", html)
        self.assertIn("scroll", html)

    def test_covers_paint_brush_usage(self):
        html = topic_html("Painting soil")
        self.assertIn("Brush Size", html)
        self.assertIn("radius", html)

    def test_covers_bed_of_nails_depth_view(self):
        html = topic_html("Soil depth (bed of nails)")
        self.assertIn("Show bed of nails", html)
        self.assertIn("Depth exaggeration", html)
        self.assertIn("Soil depth (m)", html)

    def test_covers_default_soil_initialisation(self):
        html = topic_html("Default soil initialisation").lower()
        self.assertIn("steep", html)
        self.assertIn("hollow", html)

    def test_has_troubleshooting_topic(self):
        self.assertIn("Troubleshooting", [t for t, _ in GUIDE_TOPICS])

    def test_sidebar_button_names_used_in_guide_exist_in_main_window(self):
        """Buttons named in the guide must match real MainWindow captions."""
        source = (project_root / "src" / "ui" / "MainWindow.py").read_text(encoding="utf-8")
        for caption in ("Load Terrain", "Save Terrain", "Generate New Terrain",
                        "Show bed of nails", "Depth exaggeration", "Brush Size"):
            self.assertIn(f'"{caption}"', source, f"'{caption}' not found in MainWindow")


class TestUserGuideDialog(unittest.TestCase):
    """The UserGuideDialog widget."""

    def setUp(self):
        self.dialog = UserGuideDialog()

    def tearDown(self):
        self.dialog.close()
        self.dialog.deleteLater()

    def test_window_title(self):
        self.assertEqual(self.dialog.windowTitle(), "EarthSketch 3D - User Guide")

    def test_dialog_is_not_modal(self):
        """Guide stays open beside the app so users can follow along."""
        self.assertFalse(self.dialog.isModal())

    def test_topic_list_matches_topics(self):
        self.assertEqual(self.dialog.topicList.count(), len(GUIDE_TOPICS))
        for i, (title, _) in enumerate(GUIDE_TOPICS):
            self.assertEqual(self.dialog.topicList.item(i).text(), title)

    def test_first_topic_selected_and_shown_on_open(self):
        self.assertEqual(self.dialog.topicList.currentRow(), 0)
        self.assertIn("Getting started", self.dialog.content.toPlainText())

    def test_selecting_a_topic_shows_its_content(self):
        for i, (title, _) in enumerate(GUIDE_TOPICS):
            self.dialog.topicList.setCurrentRow(i)
            self.assertIn(title.split(" (")[0], self.dialog.content.toPlainText())

    def test_show_topic_updates_content(self):
        before = self.dialog.content.toPlainText()
        self.dialog.show_topic(1)
        self.assertNotEqual(self.dialog.content.toPlainText(), before)

    def test_show_topic_negative_index_ignored(self):
        before = self.dialog.content.toPlainText()
        self.dialog.show_topic(-1)
        self.assertEqual(self.dialog.content.toPlainText(), before)

    def test_show_topic_index_too_large_ignored(self):
        before = self.dialog.content.toPlainText()
        self.dialog.show_topic(len(GUIDE_TOPICS))
        self.assertEqual(self.dialog.content.toPlainText(), before)

    def test_show_topic_by_title_jumps_to_topic(self):
        self.dialog.show_topic_by_title("Painting soil")
        expected = [t for t, _ in GUIDE_TOPICS].index("Painting soil")
        self.assertEqual(self.dialog.topicList.currentRow(), expected)
        self.assertIn("Brush Size", self.dialog.content.toPlainText())

    def test_show_topic_by_title_unknown_title_changes_nothing(self):
        self.dialog.topicList.setCurrentRow(2)
        before = self.dialog.content.toPlainText()
        self.dialog.show_topic_by_title("No such topic")
        self.assertEqual(self.dialog.topicList.currentRow(), 2)
        self.assertEqual(self.dialog.content.toPlainText(), before)

    def test_show_topic_by_title_is_case_sensitive_exact_match(self):
        self.dialog.topicList.setCurrentRow(0)
        self.dialog.show_topic_by_title("painting soil")
        self.assertEqual(self.dialog.topicList.currentRow(), 0)

    def test_close_button_closes_dialog(self):
        self.dialog.show()
        self.assertTrue(self.dialog.isVisible())
        self.dialog.btnClose.click()
        self.assertFalse(self.dialog.isVisible())

    def test_dialog_can_be_reopened_after_close(self):
        """MainWindow re-shows one cached dialog instance each time."""
        self.dialog.show()
        self.dialog.close()
        self.dialog.show()
        self.assertTrue(self.dialog.isVisible())

    def test_content_is_read_only(self):
        self.assertTrue(self.dialog.content.isReadOnly())

    def test_every_topic_renders_visible_text(self):
        for i in range(len(GUIDE_TOPICS)):
            self.dialog.show_topic(i)
            self.assertGreater(len(self.dialog.content.toPlainText().strip()), 50)


if __name__ == '__main__':
    unittest.main()
