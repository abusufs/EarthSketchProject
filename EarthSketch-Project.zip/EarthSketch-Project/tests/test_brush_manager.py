import sys
from pathlib import Path
from unittest.mock import MagicMock

# 1. Add project root to sys.path
project_root = Path(__file__).resolve().parent.parent
if str(project_root) not in sys.path:
    sys.path.insert(0, str(project_root))

# 2. Mock pyvistaqt before importing Renderer or BrushManager
sys.modules["pyvistaqt"] = MagicMock()

# 3. Imports
import unittest
from src.painting.BrushManager import BrushManager
from src.painting.RayCast import RaycastHit
from src.core.Terrain import Terrain

class TestBrushManager(unittest.TestCase):
    def setUp(self):
        self.terrain = Terrain(width=5, height=5, spacing=1.0, latitude=0.0, elevations=[[0.0]*5 for _ in range(5)])
        self.mock_renderer = MagicMock()
        self.manager = BrushManager(terrain=self.terrain, renderer=self.mock_renderer)

    def test_paint_deduplication(self):
        hit = RaycastHit(world_position=(1.0, 1.0, 0.0), cell_row=1, cell_col=1)

        # First paint event
        self.manager.paint(hit)
        self.assertEqual(self.mock_renderer.update_colours.call_count, 1)

        # Dragging mouse over same cell should NOT trigger extra paints or renders
        self.manager.paint(hit)
        self.assertEqual(self.mock_renderer.update_colours.call_count, 1)

        # Ending stroke resets cell tracking
        self.manager.end_stroke()
        self.manager.paint(hit)
        self.assertEqual(self.mock_renderer.update_colours.call_count, 2)

    def test_getters_and_setters(self):
        self.manager.set_size(5)
        self.assertEqual(self.manager.get_size(), 5)

        self.manager.set_soil_type("silt")
        self.assertEqual(self.manager.get_soil_type(), "silt")

    def test_paint_none_hit(self):
            """Verifies that passing None when RayCast misses the terrain exits safely without re-rendering."""
            self.manager.paint(None)
            
            # Access the renderer mock via the BrushManager instance
            self.manager.renderer.update_colours.assert_not_called()

if __name__ == '__main__':
    unittest.main()