from src.ui.MainWindow import main

if __name__ == "__main__":
    main()