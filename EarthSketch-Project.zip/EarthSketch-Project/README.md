# Earth Sketch 3D:

## Aim:

Creating a 3D terrain visualization and soil editing tool that allows users to efficiently generate and modify soil datasets using intuitive painting tools on digital elevation models

# How to run program:

1. Clone the repository
2. Create a python virtual environment (python -m venv .venv)
3. Activate the virtual environment (.\venv\Scripts\activate)
4. Install requirements.txt (python -m pip install -r requirements.txt)
5. If using VS code: Press Crtl + Shift + P -> Pyhton: Select Interpreter -> (select the option with the '.venv')  
6. Run EarthSketch (python run.py)