from pyvistaqt import QtInteractor
from PySide6.QtWidgets import QApplication

app = QApplication([])
w = QtInteractor()
w.show()
app.exec()